import java.io.File;
import java.util.*;

public class Graph {
    private int vertexCt;  // Number of vertices in the graph.
    int[] predecessorList;
    int[] costList;
    private int[][] capacity;  // Adjacency  matrix
    private int[][] residual; // residual matrix
    private int[][] edgeCost; // cost of edges in the matrix
    private String graphName;  //The file from which the graph was created.
    private int totalFlow; // total achieved flow
    private int source = 0; // start of all paths
    private int target; // end of all paths

    public Graph(String fileName) {
        this.vertexCt = 0;
        source  = 0;
        this.graphName = "";
        makeGraph(fileName);
        this.predecessorList  = new int[vertexCt];
        this.costList = new int[vertexCt];

    }

    /**
     * Method to add an edge
     *
     * @param source      start of edge
     * @param destination end of edge
     * @param cap         capacity of edge
     * @param weight      weight of edge, if any
     * @return edge created
     */
    private boolean addEdge(int source, int destination, int cap, int weight) {
        if (source < 0 || source >= vertexCt) return false;
        if (destination < 0 || destination >= vertexCt) return false;
        capacity[source][destination] = cap;
        residual[source][destination] = cap;
        edgeCost[source][destination] = weight;
        edgeCost[destination][source] = -weight;
        return true;
    }

    /**
     * Method to get a visual of the graph
     *
     * @return the visual
     */

    // print the graph for the user to understand where the edges are
    public String printMatrix(String label, int[][] m) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n " + label+ " \n\t ");
        for (int i=0; i < vertexCt; i++)
            sb.append(String.format("%5d", i));
        sb.append("\n");
        for (int i = 0; i < vertexCt; i++) {
            sb.append(String.format("%5d",i));
            for (int j = 0; j < vertexCt; j++) {
                sb.append(String.format("%5d",m[i][j]));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /**
     * Method to make the graph
     *
     * @param filename of file containing data
     */
    private void makeGraph(String filename) {
        try {
            graphName = filename;
            System.out.println("\n****Find Flow " + filename);
            Scanner reader = new Scanner(new File(filename));
            vertexCt = reader.nextInt();
            capacity = new int[vertexCt][vertexCt];
            residual = new int[vertexCt][vertexCt];
            edgeCost = new int[vertexCt][vertexCt];
            for (int i = 0; i < vertexCt; i++) {
                for (int j = 0; j < vertexCt; j++) {
                    capacity[i][j] = 0;
                    residual[i][j] = 0;
                    edgeCost[i][j] = 0;
                }
            }

            // If weights, need to grab them from file
            while (reader.hasNextInt()) {
                int v1 = reader.nextInt();
                int v2 = reader.nextInt();
                int cap = reader.nextInt();
                int weight = reader.nextInt();
                if (!addEdge(v1, v2, cap, weight))
                    throw new Exception();
            }

            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        target = vertexCt - 1;
        System.out.println( printMatrix("Edge Cost" ,edgeCost));
    }


    // main method to calculate both the reduced cost/flow with paths and full flow/cost
    public void minCostMaxFlow(){
        System.out.println(printMatrix("Capacity", capacity));
        findCostAndFlow();
        System.out.println(printMatrix("Residual", residual));
        totalEdgeFlowAmount();
    }

    private boolean hasCheaperPath(){

        // set both arrays to -1 and maxVal to determine where edges exist or don't exist
        predecessorList = new int[vertexCt];
        Arrays.fill(predecessorList, -1);

        costList = new int[vertexCt];
        Arrays.fill(costList, Integer.MAX_VALUE);

        // loop through to relax the edges
        costList[source] = 0;
        for (int i = 0; i < vertexCt - 1; i++){

            // loop through the residual graph to check if there are edges and update cost if a cheaper path is found
            for (int u = 0; u < vertexCt; u++){
                for (int v = 0; v < vertexCt; v++){
                    if (residual[u][v] > 0 && costList[u] != Integer.MAX_VALUE && costList[u] + edgeCost[u][v] < costList[v]){
                        // update cost and predecessor arrays
                        costList[v] = costList[u] + edgeCost[u][v];
                        predecessorList[v] = u;
                    }
                }
            }
        }
        // check if there is a path to the target
        return predecessorList[target] != -1;
    }

    private void findCostAndFlow(){
        // set up print output
        System.out.println("\nPaths found in order");
        String output;

        // loop through until all best paths are found
        while (hasCheaperPath()){
            output = "";
            int previousToEnd = predecessorList[target];
            int end = target;
            int flowAmount = Integer.MAX_VALUE;

            // go through full path moving up one node at a time
            while (end != source){
                output = previousToEnd + " " + output;
                if (residual[previousToEnd][end] < flowAmount){
                    flowAmount = residual[previousToEnd][end];
                }
                end = previousToEnd;
                previousToEnd = predecessorList[end];
            }
            // add target value for full path
            output += target;

            previousToEnd = predecessorList[target];
            end = target;

            // updates the residual graph based on the flowAmount and accounts for negative edge weights
            while (end != source){
                residual[previousToEnd][end] -= flowAmount;
                residual[end][previousToEnd] += flowAmount;

                end = previousToEnd;
                previousToEnd = predecessorList[end];
            }
            System.out.println("Path: " + output + "(" + flowAmount + ")" + " $ " + costList[target]);


        }

    }
    // Flow for each edge in the graph found by using the difference between the capacity and residual graph
    private void totalEdgeFlowAmount(){
        for (int i = 0; i < vertexCt; i++){
            for (int j = 0; j < vertexCt; j++){
                if ((capacity[i][j] - residual[i][j]) > 0){
                    int cost = edgeCost[i][j];
                    System.out.println("Flow " + i + " -> " + j + "(" + (capacity[i][j] - residual[i][j]) + ") $ " + cost);
                }
            }
        }
    }

    // main function that calls main graph function (minCostMaxFlow) and the file reading function.
    public static void main(String[] args) {
        String[] files = {"match0.txt", "match1.txt", "match3.txt", "match4.txt", "match5.txt","match6.txt", "match7.txt", "match8.txt", "match9.txt"};

        // Bonus "Flow10.txt"
        for (String fileName : files) {
            Graph graph = new Graph(fileName);
            graph.minCostMaxFlow();
        }
    }
}