public class TeaCupDynamic {
    int[] teaCupGroupAmounts;
    int[] profitFromTeaCups;
    int amountOfTeaCups;
    int[][] dynamTable;

    // construct the teacup object
    public TeaCupDynamic(int[] teaCupGroupAmounts, int[] profitFromTeaCups, int amountOfTeaCups) {
        this.amountOfTeaCups = amountOfTeaCups;
        this.profitFromTeaCups = profitFromTeaCups;
        this.teaCupGroupAmounts = teaCupGroupAmounts;
        this.dynamTable = new int[teaCupGroupAmounts.length][amountOfTeaCups + 1];
    }

    // initialize the table with values
    public void generateDynamTable() {
        for (int i = 0; i < teaCupGroupAmounts.length; i++) {
            dynamTable[i][0] = 0;
        }
        for (int j = 0; j < amountOfTeaCups + 1; j++) {
            dynamTable[0][j] = 0;
        }
    }

    // calculate values for the table
    public void fillDynamTable() {
        for (int i = 1; i < teaCupGroupAmounts.length; i++) {
            for (int j = 1; j < amountOfTeaCups + 1; j++) {
                if (i > j) {
                    // assign values based on neighbors
                    dynamTable[i][j] = dynamTable[i - 1][j];
                }
                else {
                    int dontUse = dynamTable[i - 1][j];
                    int use = profitFromTeaCups[i] + dynamTable[i][j - i];
                    // save the max value of either using or not using the higher grouping of teacups
                    dynamTable[i][j] = Math.max(dontUse, use);
                }
            }
        }
    }
    // display table with associated values to the user
    public void printTable() {
        // set up the first few lines to help indicate the rows and columns of the table
        System.out.println();
        System.out.print("   ");
        for (int output = 1; output < amountOfTeaCups + 1; output++) {
            System.out.printf("%3d", output);
        }
        System.out.println();
        System.out.print("   ");
        for (int i = 1; i < amountOfTeaCups + 1; i++) {
            System.out.printf("%3s", "--");
        }
        System.out.println();

        // print out the values in the table and make sure the first column is separated by a bar
        for (int tableSize = 1; tableSize < teaCupGroupAmounts.length; tableSize++) {
            System.out.printf("%3d", tableSize);
            for (int tableValue = 1; tableValue < amountOfTeaCups + 1; tableValue++) {
                if (tableValue == 1){
                    System.out.printf("%3s", "| " + dynamTable[tableSize][tableValue]);
                }
                else {
                    System.out.printf("%3d", dynamTable[tableSize][tableValue]);
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    // calculate the best profit from combining different teacup groups and display the num of teacups, the profit, and the groupings made
    public void findBestSum() {
        for (int numOfTeaCups = 1; numOfTeaCups < amountOfTeaCups + 1; numOfTeaCups++) {
            int bestSum = dynamTable[teaCupGroupAmounts.length - 1][numOfTeaCups];
            String sumOutput = sortCupGroups(numOfTeaCups);
            System.out.printf("Best Sum for (" + numOfTeaCups + ") : $" + bestSum + " " + sumOutput + "\n");
        }
        System.out.println();
    }
    // append the grouping numbers used to make the bestSum and return it as a string
    private String sortCupGroups(int teaCups) {
        StringBuilder cupGroup = new StringBuilder();
        int size = teaCupGroupAmounts.length - 1;
        while (teaCups != 0) {
            if (dynamTable[size][teaCups] != dynamTable[size - 1][teaCups]) {
                cupGroup.append(size).append(" ");
                teaCups -= size;
            }
            else {
                size--;
            }
        }
        return String.valueOf(cupGroup);
    }

    // call all the dynamic functions and have the whole program run
    public void fullDynamicSolve() {
        generateDynamTable();
        fillDynamTable();
        printTable();
        findBestSum();
    }

    // set up the variables needed before creating TeaCupDynamic objects
    public static void main(String[] args) {
        int[] teaCupGroupAmounts = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
        int[] dataset1 = {0, 1, 3, 7, 9, 10, 15, 17, 18, 19, 22, 25, 27};
        int[] dataset2 = {0, 2, 5, 8, 9, 10, 15, 19, 23, 24, 29, 30, 32};
        int amountOfTeaCups = 24;

        // set up the teacup object with the first dataset and call its full program
        TeaCupDynamic teaCup1 = new TeaCupDynamic(teaCupGroupAmounts, dataset1, amountOfTeaCups);
        System.out.println("Best Sums for Dataset 1");
        teaCup1.fullDynamicSolve();
        // same thing for this teacup object, but pass in the second dataset
        TeaCupDynamic teaCup2 = new TeaCupDynamic(teaCupGroupAmounts, dataset2, amountOfTeaCups);
        System.out.println("Best Sums for Dataset 2");
        teaCup2.fullDynamicSolve();
    }
}

