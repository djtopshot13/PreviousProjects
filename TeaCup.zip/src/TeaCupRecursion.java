public class TeaCupRecursion {
    private int[] returns;

    // constructor with an int array parameter to change what data it uses
    public TeaCupRecursion(int[] profits) {
        this.returns = profits;
    }

    // recursive function to generate profits based on 12 teacups
    public void displayCombinations(int amt, String soFar, int currentSize, int valueSoFar) {
        // base case to kick out of recursion
        if (amt == 0) {
            System.out.println(soFar + " $" + valueSoFar);
            return;
        }
        // the case we don't use the value
        if (currentSize > 1) {
            displayCombinations(amt, soFar, currentSize - 1, valueSoFar);
        }
        // the case we do use the value and append the profit
        if (currentSize <= amt) {
            displayCombinations(amt - currentSize, soFar + currentSize + " ", currentSize, valueSoFar + returns[currentSize - 1]);
        }
    }
    public static void main(String args[]) {
        // set up two different int arrays to be passed through to TeaCupRecursion objects
        int[] firstSetProfits = new int[]{1, 3, 7, 9, 10, 15, 17, 18, 19, 22, 25, 27};
        int[] secondSetProfits = new int[]{2, 5, 8, 9, 10, 15, 19, 23, 24, 29, 30, 32};
        // Have the teacup objects print all combinations of teacups from least to greatest prices for both arrays
        TeaCupRecursion teaCup1 = new TeaCupRecursion(firstSetProfits);
        teaCup1.displayCombinations(12, "", 12, 0);
        TeaCupRecursion teaCup2 = new TeaCupRecursion(secondSetProfits);
        teaCup2.displayCombinations(12, "", 12, 0);
    }
}