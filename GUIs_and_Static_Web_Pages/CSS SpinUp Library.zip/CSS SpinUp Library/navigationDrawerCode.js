document.addEventListener("DOMContentLoaded", () => {
    const navDrawer = document.querySelector(".nav-drawer-format");
    const menuButton = document.querySelector(".material-icons");
    menuButton.addEventListener("click", () => {
        navDrawer.classList.toggle("open");
    });
});

document.getElementById("navDrawer-HTML").innerText = `
<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="navigationDrawerStyle.css">
        <script src="navigationDrawerCode.js" defer></script>
    </head>
    <body>
        <nav class="navDrawer">
            <span class="material-icons">menu</span>
            <div class="nav-drawer-format">
            <ul class="nav-drawer-items">
                <li><a href="#">Home</a></li>
                <li><a href="#">Dashboard</a></li>
                <li><a href="#">Profile</a></li>
                <li><a href="#">Settings</a></li>
            </ul>
            </div>
        </nav>
        <div>HTML</div>
        <pre class="html" id="navDrawer-html"></pre>
        
        <div>CSS</div>
        <pre class="css" id ="navDrawer-css"></pre>
        
        <div>JS</div>
        <pre class="js" id ="navDrawer-js"></pre>
    </body>
</html>
`;

document.getElementById("navDrawer-CSS").innerText = `

.nav-drawer-format{
    top: 0;
    position: absolute;
    left: -250px;
    width: 120px;
    height: 100%;
    transition: left 0.3s ease-in-out;
}

.nav-drawer-format.open{
    left: 0px;
}

.navDrawer{
    position: relative;
}

.material-icons {
    position: absolute;
    cursor: pointer;
    padding: 0px;
    top: 0;
    left: 0;
    width: 100%;
    background-color: darkgreen;
}

.nav-drawer-items{
    list-style: none;
    margin: 20px 0;
    padding: 20px;
    background-color: darkgreen;
}

.nav-drawer-items li{
    margin-bottom: 16px;
}

.nav-drawer-items li a{
    color: maroon;
    text-decoration: none;
    display: flex;
}

html, body{
    height: 100%;
    margin: 0;
    padding: 0;
}

.HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    margin-top: 200px;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.JS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

`;

document.getElementById("navDrawer-JS").innerText = `
document.addEventListener("DOMContentLoaded", () => {
    const navDrawer = document.querySelector(".nav-drawer-format");
    const menuButton = document.querySelector(".material-icons");
    menuButton.addEventListener("click", () => {
        navDrawer.classList.toggle("open");
    });
});

`;