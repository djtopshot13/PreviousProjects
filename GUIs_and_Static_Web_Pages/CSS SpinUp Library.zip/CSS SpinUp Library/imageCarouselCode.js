document.addEventListener("DOMContentLoaded", function () {
    let imgCarouselImages = document.querySelectorAll(".image-carousel-img");
    const imgCarouselList = document.querySelector(".image-carousel-container");

    let ogIndex = 0;
    let presentIndex = 0;
    let intervalNum;

    function copySlide(){
        const slideClone = imgCarouselImages[ogIndex].cloneNode(true);
        imgCarouselList.appendChild(slideClone);

        imgCarouselImages = document.querySelectorAll(".image-carousel-img");

        ogIndex = (ogIndex + 1) % imgCarouselImages.length;
        presentIndex = (presentIndex + 1) % imgCarouselImages.length;

        refreshImageCarousel();
    }

    function refreshImageCarousel(){
    const travelDistance = (presentIndex === 0) ? 30 : 100;
    const framePercentValue = -presentIndex * travelDistance + "%";
    imgCarouselList.style.transition = "transform 0.3s ease-in-out";
    imgCarouselList.style.transform = "translateX(" + framePercentValue +")";
    }

    function carouselEngine(){
        intervalNum = setInterval(copySlide, 1500);
    }

    carouselEngine();
});

document.getElementById("ImageCarousel-HTML").innerText = `
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="imageCarouselStyle.css">
        <title>Image Carousel Page</title>
    </head>
    <body>
        <div class="image-carousel">
            <div class="image-carousel-container">
                <div class="image-carousel-img">
                    <img src="img1.webp" alt="First Image">
                </div>
                <div class="image-carousel-img">
                    <img src="img2.webp" alt="Second Image">
                </div>
                <div class="image-carousel-img">
                    <img src="img3.webp" alt="Third Image">
                </div>
                <div class="image-carousel-img">
                    <img src="img4.webp" alt="Fourth Image">
                </div>
            </div>
        </div>
        <main>
            <div>HTML</div>
            <pre class="HTML" id="ImageCarousel-HTML"></pre>
            
            <div>CSS</div>
            <pre class="CSS" id ="ImageCarousel-CSS"></pre>
            
            <div>JS</div>
            <pre class="JS" id ="ImageCarousel-JS"></pre>
        </main>
        <script src="imageCarouselCode.js"></script>
    </body>
</html>

`;

document.getElementById("ImageCarousel-CSS").innerText = `

.image-carousel{
    position: relative;
    width: 350px;
    margin: 25px auto;
    overflow: hidden;
    overflow: clip;
    overflow-clip-margin: 10em;
}

.image-carousel-container{
    display: flex;
    transition: 0.3s ease-in-out;
}

.image-carousel-img{
    flex: 0 0 100%;
    box-sizing: border-box;
}

.image-carousel-img img{
    width: 350px;
    height: 250.9px
}

.HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.JS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}


`;

document.getElementById("ImageCarousel-JS").innerText = `
document.addEventListener("DOMContentLoaded", function () {
    let imgCarouselImages = document.querySelectorAll(".image-carousel-img");
    const imgCarouselList = document.querySelector(".image-carousel-container");

    let ogIndex = 0;
    let presentIndex = 0;
    let intervalNum;

    function copySlide(){
        const slideClone = imgCarouselImages[ogIndex].cloneNode(true);
        imgCarouselList.appendChild(slideClone);

        imgCarouselImages = document.querySelectorAll(".image-carousel-img");

        ogIndex = (ogIndex + 1) % imgCarouselImages.length;
        presentIndex = (presentIndex + 1) % imgCarouselImages.length;

        refreshImageCarousel();
    }

    function refreshImageCarousel(){
    const travelDistance = (presentIndex === 0) ? 30 : 100;
    const framePercentValue = -presentIndex * travelDistance + "%";
    imgCarouselList.style.transition = "transform 0.3s ease-in-out";
    imgCarouselList.style.transform = "translateX(" + framePercentValue +")";
    }

    function carouselEngine(){
        intervalNum = setInterval(copySlide, 1500);
    }

    carouselEngine();
});

`;