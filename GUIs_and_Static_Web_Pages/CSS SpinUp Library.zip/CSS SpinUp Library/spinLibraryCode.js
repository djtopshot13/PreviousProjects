document.getElementById("spinLibrary-HTML").innerText = `
<!DOCTYPE html>
<html>
<head>
    <title>SpinUp Library</title>
    <link rel="stylesheet" href="spinLibraryStyle.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="spinLibraryCode.js" defer></script>
</head>
<body>
    <div class="cover" id="cover"></div>
    <nav class="main-navbar">
        <button class="menu-button" id="navbar-button">
            <span class="material-icons">menu</span>
        </button>
        <h1>SpinUp CSS Library</h1>
    </nav>
    <nav class="main-drawer" id="main-drawer">
        <a href="navbar.html"><span class="material-icons">home</span>Navbar</a>
        <a href="navigationDrawer.html"><span class="material-icons">favorite</span>Navigation Drawer</a>
        <a href="button-FAB.html"><span class="material-icons">download</span>Button/FAB</a>
        <a href="imageCarousel.html"><span class="material-icons">image</span>Image Carousel</a>
        <a href="LoadingSpinner.html"><span class="material-icons">sync</span>Loading Spinners</a>
    </nav>
</body>
<main>
    <div>HTML</div>
    <pre class="HTML" id="spinLibrary-HTML"></pre>
    
    <div>CSS</div>
    <pre class="CSS" id ="spinLibrary-CSS"></pre>
</main>

</html>
`;

document.getElementById("spinLibrary-CSS").innerText = `

* {
    box-sizing: border-box;
    background-color: teal;
}

body{
    margin: 0;
    height: 150vh;
}

.menu-button {
    background-color: transparent;
    border: none;
    justify-content: center;
    align-items: center;
    color: black;
    cursor: pointer;
    padding: 8px;
}

.cover {
    position: fixed;
    top: 0;
    left: 0;
    background-color: black;
    transition: background-color 1s ease;
}

.main-drawer{
    display: flex;
    flex-flow: row nowrap;
    justify-content: center;
    top: 100px;
    position: absolute;
    left: 150px;
    width: 300px;
}

a {
    font-family: Arial, Helvetica, sans-serif;
    color: purple;
    cursor: pointer;
    font-size: 24px;
    margin: 10px;
    text-align: center;
}

.HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    margin-top: 400px;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

`;