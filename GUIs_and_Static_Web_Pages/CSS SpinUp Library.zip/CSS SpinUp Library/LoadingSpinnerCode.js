const spinner = document.querySelector('.spinner2');

spinner.addEventListener('click', function() {
    if(this.classList.contains("stopped")){
        this.classList.remove("stopped");
    }
    else{
        this.classList.add("stopped");
    }
});

document.getElementById("LoadingSpinner-HTML").innerText = `
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="LoadingSpinnerStyle.css">
        <script src="LoadingSpinnerCode.js" defer></script>
        <title>Loading Spinner Page</title>
    </head>


    <body>
        <div class="dots">
            <div class="dot1" id="dot1"></div>
            <div class="dot2" id="dot2"></div>
            <div class="dot3" id="dot3"></div>
        </div>
        <div class="container2">
            <div class="spinner2" id="spinner2"></div>
            <p id="click-text">Click On Spinner to Pause or Resume</p>
        </div>

        <div class="loading-bar-container">
            <div class="loading-bar">
                <p class="load-bar-text">Loading...</p>
            </div>
        </div>
    </body>
</html>
`;

document.getElementById("LoadingSpinner-CSS").innerText = `

:root{
    --primary:  rgb(0, 128, 90);
    --secondary: rgb(3, 43, 5);
}

  .container2{
    display: flex;
    justify-content: center;
    align-items: center;
    flex-flow: column nowrap;
    padding: 40px;
  }
  #click-text{
    margin: 0;
    color: darkgreen;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 24px;
  }

  .spinner2 {
    width: 40px; /* Diameter of the spinner */
    height: 40px; /* Diameter of the spinner */
    cursor: pointer;
    border: 4px solid rgb(0,0,0,0.1); /* Border color of the spinner */
    border-top: 4px solid #3498db; /* Color of the spinning element */
    border-radius: 50%; /* Makes the element a circle */
    animation: spin 1s linear infinite; /* Animation properties */
  }
  
  .spinner2.stopped {
    animation-play-state: paused; 
  }
  
  
  /* @keyframes newspin {
    0% { transform: rotate(0deg); } /* Starting point of the spinner */
    /* 25% {border-inline-color: red;}
    50% {border-inline-color: yellow;}
    75% {border-inline-color: green;} */
    /* 100% { transform: rotate(360deg); } Full rotation of the spinner */
  /* } */
  
  /* Keyframes for spinning animation */
  @keyframes spin {
    0% { transform: rotate(0deg); } /* Starting point of the spinner */
    25% {border-top-color: red; transform: rotate(90deg);}
    50% {border-top-color: yellow; transform: rotate(180deg);}
    75% {border-top-color: green; transform: rotate(270deg);}
    100% { transform: rotate(360deg); } /* Full rotation of the spinner */
  } 
  
  .dots{
    display: flex;
    justify-content: center;
    padding: 20px, 0px, 20px, 0px;

  }

  .dot1,
  .dot2,
  .dot3{
    width: 40px;
    height: 40px;
    background-color: var(--primary);
    border-radius: 50%;
    transform: translateY(20px);
    animation: fadeAndFloat 1s linear infinite;

    
  }

  @keyframes fadeAndFloat {
    0% {
        background-color: var(--primary);
        transform: translateY(20px);
    }
    50%{
        background-color: var(--secondary);
        transform: translateY(0);
    }
    100%{
        transform: translateY(20px);
        background-color: var(--primary);
    }
  }

  .dot2{
    animation-delay: 0.3s;
  }
  
  .dot3{
    animation-delay: 0.6s;
  }
  .loading-bar-container {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-flow: column nowrap;
    font-family: Arial, sans-serif;
    color: rgb(66, 7, 100); /* Color of the text */
    position: relative;
    font-size: 100%;
    text-transform: uppercase;
  }
  
   .loading-bar {
    width: 150px; 
    height: 50px; 
    background-color: #eee; 
    overflow: hidden;
    position: relative; 
    align-items: center;
    justify-content: center;
  }
  
  /* .loading-bar-spinner::before {
    content: 'Loading...'; 
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 0;
    padding-left: 10px; 
    line-height: 20px; 
    background-color: rgb(33, 135, 139); 
    color: #696969; 
    animation: fillLoadBar 4s linear infinite; 
    white-space: nowrap; 
    overflow: hidden; 
  } */

  .load-bar-text{
    overflow: hidden;
    position: absolute;
    animation: fillLoadBar 5s linear infinite;
    text-align: center;
    width: 100%;
    transform-origin: left;
  }
  
  @keyframes fillLoadBar {
    0% {
      transform: scaleX(0);
    }
    100% {
      transform: scaleX(1);
    }
  }
  
  .HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.JS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

`;

document.getElementById("LoadingSpinner-JS").innerText = `
const spinner = document.querySelector('.spinner2');

spinner.addEventListener('click', function() {
    if(this.classList.contains("stopped")){
        this.classList.remove("stopped");
    }
    else{
        this.classList.add("stopped");
    }
});

`;