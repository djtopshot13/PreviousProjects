document.getElementById("navbar-HTML").innerText = `
<!DOCTYPE html>
<html lang="en">
    <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="navbarStyle.css">
    </head>
    <body>
        <nav class="navbar">
            <div class="format">
                <div class="left-portion">
                    <span class="material-icons">menu</span>
                    <span class="website-title">Your Website Title</span>
                </div>
                <div class="link-list">
                    <a href="fill your first link here">Page 1</a>
                    <a href="fill your second link here">Page 2</a>
                    <a href="fill your third link here">Page 3</a>
                    <a href="fill your fourth link here">Page 4</a>
                </div>
            </div>
        </nav>
    </body>
    <main>
        <div>HTML</div>
        <pre class="HTML" id="navbar-HTML"></pre>
        
        <div>CSS</div>
        <pre class="CSS" id ="navbar-CSS"></pre>
    </main>
</html>
`;

document.getElementById("navbar-CSS").innerText = `

.navbar{
    background-color: darkgreen;
}

.format{
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%
}

.material-icons{
    margin-right: 10px;
    font-size: 24px;
    cursor: default;
}

.left-portion{
    display: flex;
    align-items: center;
}

.website-title{
    font-family: Arial, Helvetica, sans-serif;
    font-size: 20px;
    font-weight: bold;
    color: maroon;
}

.link-list a{
    margin-left: 30px;
    margin-right: 10px;
    font-size: 16px;
    color: maroon;
    text-decoration: none;
}

.HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

`;

