document.getElementById("Button/FAB-HTML").innerText = `
<!DOCTYPE html>
<html>
    <head>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="navbarStyle.css">
        <script src="navbarCode.js" defer></script>
    </head>
    <body>
        <nav class="navbar">
            <div class="format">
                <div class="left-portion">
                    <span class="material-icons">menu</span>
                    <span class="website-title">Your Website Title</span>
                </div>
                <div class="link-list">
                    <a href="fill your first link here">Page 1</a>
                    <a href="fill your second link here">Page 2</a>
                    <a href="fill your third link here">Page 3</a>
                    <a href="fill your fourth link here">Page 4</a>
                </div>
            </div>
        </nav>
    </body>
    <main>
        <div>HTML</div>
        <pre class="HTML" id="navbar-HTML"></pre>
        
        <div>CSS</div>
        <pre class="CSS" id ="navbar-CSS"></pre>
    </main>
</html>
`;

document.getElementById("Button/FAB-CSS").innerText = `

#button1, 
#button2{
    height: 40px;
    width: 100px;
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
    margin-right: 10px;
    margin-left: 10px
}

#button1{
display: flex;
justify-content: center;
align-items: center;
} 

#button2{
    display: flex;
    align-items: center;
    justify-content: space-around;
}



.FAB-button{
    border-radius: 50%;
    display: flex;
    width: 40px;
    height: 40px;
    overflow: hidden;
    justify-content: center;
    align-items: center;
    margin-right: 10px;
    color: white;
    box-shadow: 0 6px 14px rgba(0, 0, 0, 0.6);
    margin-left: 10px
}

button{
    background-color: maroon;
    cursor: pointer;
}

button:hover{
    background-color: darkgreen;
    cursor: pointer;
}


.material-icons{
font-size: 24px;
}

.button-text{
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
}

.button-format {
    display: inline-flex;
    width: 100%;
    justify-content: space-evenly;
}

.button-format span{
    display: flex;
}

.HTML {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

.CSS {
    flex-wrap: nowrap;
    display: flex;
    min-width: 50%;
    width: fit-content;
    padding: 5px;
    border-radius: 5px;
    background-color: rgb(90, 90, 90);
    margin-bottom: 30px;
}

`;
