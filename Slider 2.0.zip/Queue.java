
public class Queue<E> implements List<E> {
    private class Node {
        public Node next;
        public E state;

        // this Node object will hold the board state info in a linked list
        public Node(E state) {
            this.state = state;
        }
    }
    private Node head;
    private Node tail;

    // counters to keep track of adding, subtracting, and the total length of the linked list
    private int countAdd = 0;
    private int countRemove = 0;
    private int queueLength = 0;

    // add to the bottom of the list.
    public void add(E state) {
        Node node = new Node(state);
        if (tail == null) {
            tail = node;
            head = node;
        } else {
            tail.next = node;
            tail = node;
        }
        countAdd++;
        queueLength++;
    }
    // These two methods are implementations of the List superclass's methods
    @Override
    public E deleteLast() {
        return remove();
    }
    @Override
    public void insert(E state){
            add(state);
    }

    // remove from the top of the linked list
    private E remove() {
        if (head == null) {
            return null;
        } else if (queueLength == 1) {
            countRemove++;
            Node previousHead = head;
            head = null;
            tail = null;
            queueLength--;
            return previousHead.state;
        } else {
            Node previousHead = head;
            head = head.next;
            countRemove++;
            queueLength--;
            return previousHead.state;
        }

    }

    // print the state id and corresponding steps
    public void printQueue() {
        Node checkNode = head;
        while (checkNode != null) {
            System.out.print("[" + checkNode.state + "] ");
            checkNode = checkNode.next;
        }
        System.out.println();
    }

    // minus 1 since we don't count the head
    public int getCountAdd() {
        return countAdd - 1;
    }

    public int getCountRemove() {
        return countRemove;
    }
}