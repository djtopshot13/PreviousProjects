// interface to be used by both A* and
public interface List<E> {
    E deleteLast();
    void insert(E e);
}
