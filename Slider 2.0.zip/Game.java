import java.util.Scanner;
import java.util.*;

import static java.lang.Integer.parseInt;

public class Game {
    private static final String SOLVED_ID = "123456780";
    Board theBoard;
    String originalBoardID;
    String boardName;


    /**
     * Solve the provided board
     *
     * @param label Name of board (for printing)
     * @param b     Board to be solved
     */
    public void playGiven(String label, Board b) {
        theBoard = b;
        originalBoardID = b.getId();
        boardName = label;
        System.out.println("Board initial: " + boardName + " \n\n" + theBoard.toString());

        // ask user for which solve method they want
        System.out.println("Please give an input from 0-2 for the desired solve method:\n" +
                "0 - Brute Force Solve       1 - A* Solve       2 - Both Methods");
        Scanner in = new Scanner(System.in);
        int choice = in.nextInt();
        if (choice == 0) {
            System.out.println("Brute Force Solve");
            bruteForceSolve();
        }
        else if (choice == 1){
            System.out.println("A* Solve");
            AVLSolve();
        }
        else{
            System.out.println("Brute Force and A* Solve:");
            System.out.println("\nBrute Force Solve");
            bruteForceSolve();
            System.out.println("\nA* Solve");
            AVLSolve();
        }
    }

    /**
     * Create a random board (which is solvable) by jumbling jumbleCount times.
     * Solve
     *
     * @param label       Name of board (for printing)
     * @param jumbleCount number of random moves to make in creating a board
     */
    public void playRandom(String label, int jumbleCount) {
        theBoard = new Board();
        theBoard.makeBoard(jumbleCount);
        System.out.println(label + "\n" + theBoard);
        playGiven(label, theBoard);


    }


    public static void main(String[] args) {
        String[] games = {"102453786", "123740658", "023156478", "413728065", "145236078", "123456870"};
        String[] gameNames = {"Easy Board", "Game1", "Game2", "Game3", "Game4", "Game5 No Solution"};
        Game g = new Game();
        Scanner in = new Scanner(System.in);
        Board b;
        String resp;
        for (int i = 0; i < games.length; i++) {
            b = new Board(games[i]);
            g.playGiven(gameNames[i], b);
        }


        boolean playAgain = true;
        //playAgain = false;

        int JUMBLECT = 18;  // how much jumbling to do in random board
        while (playAgain) {
            g.playRandom("Random Board", JUMBLECT);

            System.out.println("Play Again?  Answer Y for yes\n");
            resp = in.nextLine().toUpperCase();
            playAgain = (resp != "") && (resp.charAt(0) == 'Y');
        }


    }

    // solve method to be used by both the A* solve and Brute Force solve method
    public void solve(List<State> dataStructure) {
        // counters for boards created and deleted
        int numCreated = 0;
        int numChecked = 0;

        // create different states based on which data structure is used
        State originalState;
        if (dataStructure instanceof Queue) {
            originalState = new State(originalBoardID, "");
        } else {
            int startDistance = new State(originalBoardID, "").getDistance();
            originalState = new State(originalBoardID, "", startDistance, startDistance);
        }

        // add start board to the data structure
        dataStructure.insert(originalState);


        // set up the moves to be iterated over in a for each loop
        char[] moves = "DURL".toCharArray();
        boolean check = false;
        boolean possible = true;

        // the loop where all the work will be done
        while (!check) {
            int MAX_NUM_OF_STEPS = 29;
            // check for unsolvable boards
            if (originalState.getNumSteps() > MAX_NUM_OF_STEPS || theBoard.getId().equals("123456870")) {
                System.out.println("This board has no solution");
                possible = false;
                check = true;
                break;
            }
            // check first board and set up new state
            State presentState = dataStructure.deleteLast();
            numChecked++;
            Board oldBoard = new Board();
            int[] presentValues = new int[9];
            String[] presentId = presentState.getId().split("");
            for (int i = 0; i < presentId.length; i++) {
                presentValues[i] = parseInt(presentId[i]);
            }
            oldBoard.makeBoard(presentValues);
            theBoard.makeBoard(presentValues);

            // Check all viable moves and create new boards with the shifted ids
            for (char i : moves) {
                if (theBoard.makeMove(i, presentState.getLast())) {
                    State childState;
                    if (dataStructure instanceof AVLTree){
                        // Set up best first algorithm
                        int mDistance = new State(theBoard.getId(), "" + i).getDistance();
                        int priority = mDistance + presentState.getNumSteps();
                            childState = new State(theBoard.getId(), presentState.getSteps() + "" + i, mDistance, priority + 1);
                    }
                    else {
                        // Brute Force version is as before
                            childState = new State(theBoard.getId(), presentState.getSteps() + "" + i);
                    }
                    dataStructure.insert(childState);
                    numCreated++;
                    // check if the board is done and print proper output
                    if ((SOLVED_ID).equals(childState.getId())) {
                        System.out.println(new Board(originalBoardID));
                        printMoves(childState.getSteps());
                        System.out.println(boardName);
                        System.out.println("Solution: " + childState.getSteps() + "(" + childState.getNumSteps() + ")");
                        System.out.println("Added to the Queue=" + numCreated + "\nRemoved from the Queue=" + numChecked);
                        System.out.println();
                        check = true;
                        break;
                    }
                }
                // reset board for the loop
                theBoard.makeBoard(presentValues);
            } // reset board for the loop
            theBoard.makeBoard(presentValues);
        }
        // if impossible board is found print error statement
        if (!possible){
            System.out.println("It cannot be solved");
        }
    }

    // A* method
    public void AVLSolve() {
        solve(new AVLTree<>());
    }

    // Brute Force method
   public void bruteForceSolve() {
        solve(new Queue<>());
}


    // takes the steps as a parameter and prints out the move followed by the corresponding changed board
    public void printMoves(String moves) {
        theBoard = new Board(originalBoardID);

        for (int i = 0; i < moves.length(); i++) {
            System.out.println(moves.charAt(i) + "===>");

            // print the original board with this if case
            if (i == 0) {
                theBoard.makeMove(moves.charAt(i), ' ');
                System.out.println(theBoard);
            } else {
                theBoard.makeMove(moves.charAt(i), moves.charAt(i - 1));
                System.out.println(theBoard);
            }
        }
    }
}