//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//
public class AVLTree<AnyType extends Comparable<? super AnyType>> implements List<AnyType> {
    private static final int ALLOWED_IMBALANCE = 1;
    private AvlNode<AnyType> root = null;

    public AVLTree() {
        root = null;
    }

    // These two methods are implementations of the List superclass's methods
    @Override
    public AnyType deleteLast(){
        AnyType minVal = findMin();
        deleteMin();
        return minVal;

    }
    @Override
    public void insert(AnyType x) {
        root = insert(x, root);
    }

    public void remove(AnyType x) {
        this.root = this.remove(x, this.root);
    }

    private AvlNode<AnyType> remove(AnyType x, AvlNode<AnyType> t) {
        if (t == null) {
            return t;
        } else {
            int compareResult = x.compareTo(t.element);
            if (compareResult < 0) {
                t.left = this.remove(x, t.left);
            } else if (compareResult > 0) {
                t.right = this.remove(x, t.right);
            } else if (t.left != null && t.right != null) {
                t.element = this.findMin(t.right).element;
                t.right = this.remove(t.element, t.right);
            } else {
                t = t.left != null ? t.left : t.right;
            }

            return this.balance(t);
        }
    }

    public AnyType findMin() {
        if (this.isEmpty()) {
            throw new RuntimeException();
        } else {
            return this.findMin(this.root).element;
        }
    }

    public void deleteMin() {
        this.root = this.deleteMin(this.root);
    }

    public AnyType findMax() {
        if (this.isEmpty()) {
            throw new RuntimeException();
        } else {
            return this.findMax(this.root).element;
        }
    }

    public boolean contains(AnyType x) {
        return this.contains(x, this.root);
    }

    public void makeEmpty() {
        this.root = null;
    }

    public boolean isEmpty() {
        return this.root == null;
    }

    public void printTree(String label) {
        System.out.println(label);
        if (this.isEmpty()) {
            System.out.println("Empty tree");
        } else {
            this.printTree(this.root, "\t");
        }

    }

    private AvlNode<AnyType> balance(AvlNode<AnyType> t) {
        if (t == null) {
            return t;
        } else {
            if (this.height(t.left) - this.height(t.right) > 1) {
                if (this.height(t.left.left) >= this.height(t.left.right)) {
                    t = this.rightRotation(t);
                } else {
                    t = this.doubleRightRotation(t);
                }
            } else if (this.height(t.right) - this.height(t.left) > 1) {
                if (this.height(t.right.right) >= this.height(t.right.left)) {
                    t = this.leftRotation(t);
                } else {
                    t = this.doubleLeftRotation(t);
                }
            }

            t.height = Math.max(this.height(t.left), this.height(t.right)) + 1;
            return t;
        }
    }

    public void checkBalance() {
        this.checkBalance(this.root);
    }

    private int checkBalance(AvlNode<AnyType> t) {
        if (t == null) {
            return -1;
        } else {
            if (t != null) {
                int hl = this.checkBalance(t.left);
                int hr = this.checkBalance(t.right);
                if (Math.abs(this.height(t.left) - this.height(t.right)) > 1 || this.height(t.left) != hl || this.height(t.right) != hr) {
                    System.out.println("\n\n***********************OOPS!!");
                }
            }

            return this.height(t);
        }
    }

    private AvlNode<AnyType> insert(AnyType x, AvlNode<AnyType> t) {
        if (t == null) {
            return new AvlNode(x, (AvlNode)null, (AvlNode)null);
        } else {
            int compareResult = x.compareTo(t.element);
            if (compareResult < 0) {
                t.left = this.insert(x, t.left);
            } else {
                t.right = this.insert(x, t.right);
            }

            return this.balance(t);
        }
    }

    // go to the farthest left child on the tree
    private AvlNode<AnyType> findMin(AvlNode<AnyType> t) {
        if (t == null) {
            return t;
        } else {
            while(t.left != null) {
                t = t.left;
            }

            return t;
        }
    }

    // use base case and check to the left as far as possible.
    // If there are no left children, then delete the root and assign its right child to it.
    private AvlNode<AnyType> deleteMin(AvlNode<AnyType> t) {
        if (t == null) {
            return null;
        } else {
            if (t.left != null) {
                t.left = this.deleteMin(t.left);
            } else {
                t = t.right;
            }

            return this.balance(t);
        }
    }

    private AvlNode<AnyType> findMax(AvlNode<AnyType> t) {
        if (t == null) {
            return t;
        } else {
            while(t.right != null) {
                t = t.right;
            }

            return t;
        }
    }

    private boolean contains(AnyType x, AvlNode<AnyType> t) {
        while(true) {
            if (t != null) {
                int compareResult = x.compareTo(t.element);
                if (compareResult < 0) {
                    t = t.left;
                    continue;
                }

                if (compareResult > 0) {
                    t = t.right;
                    continue;
                }

                return true;
            }

            return false;
        }
    }

    private void printTree(AvlNode<AnyType> t, String indent) {
        if (t != null) {
            this.printTree(t.right, indent + "   ");
            System.out.println(indent + String.valueOf(t.element) + "(" + t.height + ")");
            this.printTree(t.left, indent + "   ");
        }

    }

    private int height(AvlNode<AnyType> t) {
        return t == null ? -1 : t.height;
    }

    private AvlNode<AnyType> rightRotation(AvlNode<AnyType> t) {
        AvlNode<AnyType> theLeft = t.left;
        t.left = theLeft.right;
        theLeft.right = t;
        t.height = Math.max(this.height(t.left), this.height(t.right)) + 1;
        theLeft.height = Math.max(this.height(theLeft.left), t.height) + 1;
        return theLeft;
    }

    private AvlNode<AnyType> leftRotation(AvlNode<AnyType> t) {
        AvlNode<AnyType> theRight = t.right;
        t.right = theRight.left;
        theRight.left = t;
        t.height = Math.max(this.height(t.left), this.height(t.right)) + 1;
        theRight.height = Math.max(this.height(theRight.right), t.height) + 1;
        return theRight;
    }

    private AvlNode<AnyType> doubleRightRotation(AvlNode<AnyType> t) {
        t.left = this.leftRotation(t.left);
        return this.rightRotation(t);
    }

    private AvlNode<AnyType> doubleLeftRotation(AvlNode<AnyType> t) {
        t.right = this.rightRotation(t.right);
        return this.leftRotation(t);
    }

    public static void main(String[] args) {
        new AVLTree();
        AVLTree<Dwarf> t2 = new AVLTree();
        String[] nameList = new String[]{"Snowflake", "Sneezy", "Doc", "Grumpy", "Bashful", "Dopey", "Happy", "Doc", "Grumpy", "Bashful", "Doc", "Grumpy", "Bashful"};

        int i;
        for(i = 0; i < nameList.length; ++i) {
            t2.insert(new Dwarf(nameList[i]));
        }

        t2.printTree("The Tree");
        t2.remove(new Dwarf("Bashful"));
        t2.printTree("The Tree after delete Bashful");

        for(i = 0; i < 8; ++i) {
            t2.deleteMin();
            t2.printTree("\n\n The Tree after deleteMin");
        }

    }

    private static class AvlNode<AnyType> {
        AnyType element;
        AvlNode<AnyType> left;
        AvlNode<AnyType> right;
        int height;

        AvlNode(AnyType theElement) {
            this(theElement, (AvlNode)null, (AvlNode)null);
        }

        AvlNode(AnyType theElement, AvlNode<AnyType> lt, AvlNode<AnyType> rt) {
            this.element = theElement;
            this.left = lt;
            this.right = rt;
            this.height = 0;
        }
    }
}