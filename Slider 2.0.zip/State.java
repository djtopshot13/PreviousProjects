/*
Very simple object to contain steps and id. The board does the heavy lifting.
 */

public class State implements Comparable<State> {
    private String steps;
    private String id;
    // manhattan distance
    private int distance;
    // priority based on num of steps and distance
    private int priority;


    State(String id, String steps) {
        this.steps = steps;
        this.id = id;
    }
    // constructor for AVL Tree
    State(String id, String steps, int distance, int priority){
        this.steps = steps;
        this.id = id;
        this.distance = distance;
        this.priority = priority;
    }

    /**
     * @return last move made
     */
    public char getLast(){
        if (steps.equals("")) return '*';
        int last = steps.length();
        return steps.charAt(last-1);
    }
    public String getId() {
        return id;
    }

    public String getSteps() {
        return steps;
    }
    private int getDistance(String id) {
        int distance = 0;
        for (int i = 0; i < id.length(); i++) {
            String firstLetter = id.charAt(i) + "";
            int num = Integer.parseInt(firstLetter);
            if (num == 0) {
                continue;
            }
            else if (num != (i-1)) {
                int xPosition = i % 3;
                int yPosition = i / 3 ;
                int xActual = Math.abs(xPosition - (num - 1) % 3);
                int yActual = Math.abs(yPosition - (num - 1) / 3);
                distance += xActual + yActual;
            }
        }
        return distance;
    }

    public int getDistance(){
        return getDistance(id);
    }
    public int getPriority(){
        return distance + getNumSteps();
    }

    public int getNumSteps() {
        return steps.length();
    }
    public String toString(){
        return "State " + id + " steps: " + steps;

    }

    public int compareTo(State s2){
        return Integer.compare(this.priority, s2.priority);
    }
}