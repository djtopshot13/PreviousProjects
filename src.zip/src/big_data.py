#!/usr/bin/env python  	  	  

#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

import time  	  	  
import sys  	  	  
from report import print_report  	  	  


# print_report takes a dictionary with these contents:  	  	  
rpt = {  	  	  
        'year': 2021,  	  	  

        'all': {  	  	  
            'num_areas': 0,  	  	  
            'total_annual_wages': 0,  	  	  
            'max_annual_wage': ["", 0],  	  	  
            'total_estab': 0,  	  	  
            'max_estab': ["", 0],  	  	  
            'total_empl': 0,  	  	  
            'max_empl': ["", 0],  	  	  
        },  	  	  

        'soft': {  	  	  
            'num_areas': 0,  	  	  
            'total_annual_wages': 0,  	  	  
            'max_annual_wage': ["", 0],  	  	  
            'total_estab': 0,  	  	  
            'max_estab': ["", 0],  	  	  
            'total_empl': 0,  	  	  
            'max_empl': ["", 0],  	  	  
        },  	  	  
}  	  	  

# Print usage message if insufficient number of arguments are given
if len(sys.argv) <= 1:
    print("Usage: src/big_data.py DATA_DIRECTORY")
else:
    # Print with destination to standard error.
    print("Reading the databases...", file=sys.stderr)
    before = time.time()

    """I opened the args/area-titles.csv
    Create an empty dictionary and use a for loop to print each line into the dictionary 
    Made sure to get rid of the \" and split the fips code from the county and state name. 
    Connected each fips code to the county and state name in the empty dictionary.
    Close the file
    """
    titlesDict = {}
    f = open((sys.argv[1] + "/area-titles.csv"))
    for line in f:
        newLine = line.replace("\"", "").split(',', maxsplit=1)
        if newLine[0][0:1].isdigit() and int(newLine[0][2:]) != 0:
            fipsCode = newLine[0]
            titlesDict[fipsCode] = newLine[1]
    f.close()

    """I opened the args/2021.annual.singlefile.csv 
    Initialized a bunch of variables to gather the data that will be printed in the report. 
    I use a for loop to go through each line after it's been stripped of \n and had \" replaced.
    I used conditionals to check if the fips code on the line is valid by seeing if it's in the titlesDict
    I used conditionals to also check the ownership and industry code before augmenting my general variables for both 
        software and all industries.
    I compared the values of each line to find the max number and area for wage, employment, and establishments.
    I made sure to make most of the variables integers, so they could be compared with > and also augment too.
    Then I closed the file
    """
    f = open(sys.argv[1] + "/2021.annual.singlefile.csv")

    allAreas = 0
    allEstab = 0
    allEmploy = 0
    allWage = 0

    allMaxEstab = 0
    allMaxEstabArea = 0
    allMaxEmploy = 0
    allMaxEmployArea = 0
    allMaxWage = 0
    allMaxWageArea = 0

    softAreas = 0
    softEstab = 0
    softEmploy = 0
    softWage = 0

    softMaxEstab = 0
    softMaxEstabArea = 0
    softMaxEmploy = 0
    softMaxEmployArea = 0
    softMaxWage = 0
    softMaxWageArea = 0

    for line in f:
        newLine = line.replace("\"", "").split(",")
        if newLine[0] in titlesDict and newLine[1] == "0" and newLine[2] == "10":
            allAreas += 1

            allEstab += int(newLine[8])
            if int(newLine[8]) > allMaxEstab:
                allMaxEstabArea = titlesDict[newLine[0]]
                allMaxEstab = int(newLine[8])

            allEmploy += int(newLine[9])
            if int(newLine[9]) > allMaxEmploy:
                allMaxEmployArea = titlesDict[newLine[0]]
                allMaxEmploy = int(newLine[9])

            allWage += int(newLine[10])
            if int(newLine[10]) > allMaxWage:
                allMaxWageArea = titlesDict[newLine[0]]
                allMaxWage = int(newLine[10])

        elif newLine[0] in titlesDict and newLine[1] == "5" and newLine[2] == "5112":
            softAreas += 1
            softEstab += int(newLine[8])
            if int(newLine[8]) > softMaxEstab:
                softMaxEstabArea = titlesDict[newLine[0]]
                softMaxEstab = int(newLine[8])

            softEmploy += int(newLine[9])
            if int(newLine[9]) > softMaxEmploy:
                softMaxEmployArea = titlesDict[newLine[0]]
                softMaxEmploy = int(newLine[9])

            softWage += int(newLine[10])
            if int(newLine[10]) > softMaxWage:
                softMaxWageArea = titlesDict[newLine[0]]
                softMaxWage = int(newLine[10])

        else:
            continue
    f.close()

    """Here's the report dictionary that I input the data I gathered. 
    I had to make sure that if area inputs = 0 to print an empty string.
    Otherwise, I just input the correct variables in their proper position. 
    I used the rpt["all"] for all industries and rpt["soft"] for the software industries too. 
    """
    rpt['all']['num_areas'] = allAreas

    rpt['all']['total_annual_wages'] = allWage
    if str(allMaxWageArea).strip("\n") != "0":
        rpt['all']['max_annual_wage'] = [str(allMaxWageArea).strip("\n"), allMaxWage]
    else:
        rpt['all']['max_annual_wage'] = ["", allMaxWage]

    rpt['all']['total_estab'] = allEstab
    if str(allMaxEstabArea).strip("\n") != "0":
        rpt['all']['max_estab'] = [str(allMaxEstabArea).strip("\n"), allMaxEstab]
    else:
        rpt['all']['max_estab'] = ["", allMaxEstab]

    rpt['all']['total_empl'] = allEmploy
    if str(allMaxEmployArea).strip("\n") != "0":
        rpt['all']['max_empl'] = [str(allMaxEmployArea).strip("\n"), allMaxEmploy]
    else:
        rpt['all']['max_empl'] = ["", allMaxEmploy]

    rpt['soft']['num_areas'] = softAreas

    rpt['soft']['total_annual_wages'] = softWage
    if str(softMaxWageArea).strip("\n") != "0":
        rpt['soft']['max_annual_wage'] = [str(softMaxWageArea).strip("\n"), softMaxWage]
    else:
        rpt['soft']['max_annual_wage'] = ["", softMaxWage]

    rpt['soft']['total_estab'] = softEstab
    if str(softMaxEstabArea).strip("\n") != "0":
        rpt['soft']['max_estab'] = [str(softMaxEstabArea).strip("\n"), softMaxEstab]
    else:
        rpt['soft']['max_estab'] = ["", softMaxEstab]

    rpt['soft']['total_empl'] = softEmploy
    if str(softMaxEmployArea).strip("\n") != "0":
        rpt['soft']['max_empl'] = [str(softMaxEmployArea).strip("\n"), softMaxEmploy]
    else:
        rpt['soft']['max_empl'] = ["", softMaxEmploy]

    # Get end time and subtract the beginning from it to get the total time to be printed to the STDERR file.
    after = time.time()
    print(f"Done in {after - before:.3f} seconds!", file=sys.stderr)

    # Print the report
    print_report(rpt)
