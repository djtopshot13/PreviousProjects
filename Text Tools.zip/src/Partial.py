#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  
import Usage

def head(args):  	  	  
    """output the first part of files"""
    """Make sure there's arguments in the function.
        This portion is the default without \"-n\".
        If there are multiple files, it'll print a banner
        with the file name."""
    if args != []:
        if args[0] != "-n":
            for file in args:
                if len(args) > 1:
                    print("==> " + file + " <==")
                f = open(file)
                f.seek(0)
                for line in range(10):
                    print(f.readline(), end="")
                print()
                f.close()

        """This portion covers a command with \"-n\".
            Use args[1] as the number of iterations for printing lines.
            If there are multiple files, it'll print a banner
            with the file name."""
        if args[0] == "-n":
            if len(args) > 1:
                if args[1].isdigit():
                    for file in args[2:]:
                        if len(args) > 3:
                            print("==> " + file + " <==")
                        f = open(file)
                        f.seek(0)
                        for line in range(int(args[1])):
                            print(f.readline(), end="")
                        print()
                        f.close()

        # Else statements that deal with errors and call Usage to print proper statements.
                else:
                    Usage.usage("Number of lines is required", "head")
            else:
                Usage.usage("Number of lines is required", "head")
    else:
        Usage.usage("Too few arguments", "head")






def tail(args):  	  	  
    """output the last part of files"""
    """ Make sure that args isn't empty.
        This portion covers a command with \"-n\".
        Use args[1] as the number of iterations for printing lines.
        If there are multiple files, it'll print a banner   
        with the file name."""
    if args != []:
        if args[0] == "-n":
            # This weird nested if-else statement is for printing proper error statements.
            if len(args) < 3:
                if len(args) < 2:
                    Usage.usage("Number of lines is required", "tail")
                elif args[1].isdigit():
                    Usage.usage("Too few arguments", "tail")
                else:
                    Usage.usage("Number of lines is required", "tail")
            # Here is where the "-n" command runs with n lines printed for a single file
            elif len(args) == 3:
               for file in args[2:]:
                    f = open(file)
                    list1 = []
                    lineCount = args[1]
                    for line in f:
                        list1.append(line)
                    f.close()
                    lenList = len(list1)
                    for line in list1[int(lenList) - int(lineCount):]:
                        print(line, end="")
            # Here is where the "-n" command runs with n lines printed for multiple files
            else:
                for file in args[2:]:
                    f = open(file)
                    list1 = []
                    print("==> " + file + " <==")
                    lineCount = args[1]
                    for line in f:
                        list1.append(line)
                    f.close()
                    lenList = len(list1)
                    for line in list1[int(lenList) - int(lineCount):]:
                        print(line, end="")
                    print()

            """This portion covers a command with \"-n\".
              Use 10 as the number of iterations for printing lines.
              If there are multiple files, it'll print a banner   
              with the file name."""
        else:
            if len(args) < 1:
                Usage.usage("Too few arguments", "tail")
                # In case of 1 file used as an arg.
            elif len(args) == 1:
                for file in args:
                    f = open(file)
                    list1 = []
                    for line in f:
                        list1.append(line)
                    f.close()
                    lenList = len(list1)
                    if lenList < 10:
                        for line in list1:
                            print(line, end="")
                    else:
                        for line in list1[int(lenList) - 10:]:
                            print(line, end="")
                # In case of multiple files this for loop is used.
            else:
                for file in args:
                    f = open(file)
                    list1 = []
                    print("==> " + file + " <==")
                    for line in f:
                        list1.append(line)
                    f.close()
                    lenList = len(list1)
                    if lenList < 10:
                        for line in list1:
                            print(line, end="")
                    else:
                        for line in list1[int(lenList) - 10:int(lenList)]:
                            print(line, end="")
                    print()
        # Else for proper error statement by calling Usage.
    else:
        Usage.usage("Too few arguments", "tail")



