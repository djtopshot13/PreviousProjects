#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  
import Usage

def cat(args):
    """
    for each filename in args
        open a file
        for each line in the file
            print(line), but don't add an extra \n
        close the file
    """
    if args != []:
        for file in args:
            f = open(file)
            for line in f:
                print(line, end='')
            f.close()
    else:
        Usage.usage("Too few arguments", "cat")

def tac(args):  	  	  
    """concatenate and print files in reverse"""

    """ Make sure that args isn't empty
        Create an empty list after opening the file
        Reverse the order of the list
        Iterate by item and print the list
        If args is empty, call Usage for an error statement"""
    if args != []:
        for file in args:
            f = open(file)
            list = []
            for line in f:
                list.append(line)
            f.close()
            list.reverse()
            for i in list:
                print(i, end="")
    else:
        Usage.usage("Too few arguments", "tac")


