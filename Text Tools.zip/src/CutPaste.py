#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  
import Usage

def cut(args):  	  	  
    """remove sections from each line of files"""
    # Make sure args isn't empty, and if so, call Usage for error statement.
    if args == []:
        Usage.usage("Too few arguments", "cut")

    """ This section is for default calls without a specified field.
        Here the field is assigned as 1 as a default. 
        The lines are stripped of new lines and split from commas 
        to have separate values within a list, instead of one large value."""
    if args[0] != "-f":
        for file in args:
            f = open(file)
            newLine = []
            field = 1
            for line in f:
                newLine.append(line.strip("\n"))
            for i in newLine:
                listSep = i.split(",")
                print(listSep[field - 1])

        """ This section is for a file call with a single specified field.
            Here the field is assigned as args[1] if there's only one field given.
            The majority of error statements are found here.  
            The lines are stripped of new lines and split from commas 
            to have separate values within a list, instead of one large value."""
    else:
        sepArgs = args[1].split(",")
        """ Make sure that sepArgs is one value, 
        it isn't empty, and 
        that it's a positive integer"""
        if len(sepArgs) == 0:
            Usage.usage("A comma-separated field specification is required", "cut")
        elif len(sepArgs) == 1:
            if sepArgs[0].isdigit():
                if int(sepArgs[0]) <= 0:
                    Usage.usage("A comma-separated field specification is required", "cut")
                    """ Here's where the for loop starts for 
                        a single field specified function call."""
                else:
                    for file in args[2:]:
                        f = open(file)
                        field = sepArgs[0]
                        newLine = []
                        for line in f:
                            newLine.append(line.strip("\n"))
                        for i in newLine:
                            listSep = i.split(",")
                            """ This if-else is prints empty lines to the 
                                length of the longest file if the field given 
                                is larger than the number of data fields."""
                            if int(field) > len(listSep):
                                print()
                            else:
                                print(listSep[int(field) - 1])
            else:
                Usage.usage("A comma-separated field specification is required", "cut")

            """ This section is for a file call with multiple specified fields.
                Here the field is assigned as args[i].
                The lines are stripped of new lines and split from commas 
                to have separate values within a list, instead of one large value."""
        else:
            sepArgs.sort()
            for i in range(len(sepArgs)):
                if sepArgs[i].isdigit() and int(sepArgs[i]) > 0:
                        for file in args[2:]:
                            f = open(file)
                            field = sepArgs[i]
                            newLine = []
                            for line in f:
                                newLine.append(line.strip("\n"))
                            for i in newLine:
                                listSep = i.split(",")
                                """ This if-else is prints empty lines to the 
                                    length of the longest file if the field given 
                                    is larger than the number of data fields."""
                                if int(field) > len(listSep):
                                    print()
                                else:
                                    print(listSep[int(field) - 1])

def paste(args):  	  	  
    """merge lines of files"""
    """ Make sure args isn't empty
        Find the length of the longest file 
        Iterate in the range of the longest file
        Append the file line by line into a list"""
    if args == []:
        Usage.usage("Too few arguments", "paste")
    totalData = []
    longestFile = 0
    for file in args:
        lineCount = 0
        f = open(file)
        for line in f:
            lineCount += 1
        f.close()
        if lineCount > longestFile:
            longestFile = lineCount
        else:
            continue

    for file in args:
        f = open(file)
        totalData.append(f)
    for line in range(longestFile):
        newLine = []
        for file in totalData:
            newLine.append(file.readline().strip())
            # Use join to connect each line with a ","
        print(",".join(newLine))