#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

import Usage

def wc(files):  	  	  
    """print newline, word, and byte counts for each file"""
    """ Create variables for total count and fileNum
        in case of multiple files being called. 
        Make sure there's at least 1 file given as an argument.
        Create count variables within loop to reset after each file.
        Increment after each line.
        Print the count variables with tabs to separate them by columns.
        Check to see if there's more than 1 file and then print the total variables.
        Else statement for error is called from Usage."""
    lineTotal = 0
    wordTotal = 0
    charTotal = 0
    fileNum = 0
    if len(files) != 0:
        for file in files:
            lineCount = 0
            wordCount = 0
            charCount = 0
            f = open(file)
            for line in f:
                lineCount += 1
                wordCount += len(line.split())
                charCount += len(line)
            print(str(lineCount) + "\t\t" + str(wordCount) + "\t\t" + str(charCount) +
                  "\t\t" + file)
            f.close()
            lineTotal += lineCount
            wordTotal += wordCount
            charTotal += charCount
            fileNum += 1
            if fileNum == len(files) and len(files) > 1:
                print(str(lineTotal) + "\t\t" + str(wordTotal) + "\t\t" + str(charTotal) + "\t\tTotal")

    else:
        Usage.usage("Too few arguments", "wc")





