import java.util.ArrayList;
import java.util.Collections;

// ******************ERRORS********************************
// Throws UnderflowException as appropriate
//import org.junit.Assert;
class UnderflowException extends RuntimeException {
    /**
     * Construct this exception object.
     *
     * @param message the error message.
     */
    public UnderflowException(String message) {
        super(message);
    }
}

public class Tree<E extends Comparable<? super E>> {
    private BinaryNode<E> root;  // Root of tree
    private String treeName;     // Name of tree

    /**
     * Create an empty tree
     * @param label Name of tree
     */
    public Tree(String label) {
        treeName = label;
        root = null;
    }

    /**
     * Create tree from list
     * @param arr   List of elements
     * @param label Name of tree
     * @ordered true if want an ordered tree
     */
    public Tree(E[] arr, String label, boolean ordered) {
        treeName = label;
        if (ordered) {
            root = null;
            for (int i = 0; i < arr.length; i++) {
                bstInsert(arr[i]);
            }
        } else root = buildUnordered(arr, 0, arr.length - 1);
    }


    /**
     * Build a NON BST tree by inorder
     * @param arr nodes to be added
     * @return new tree
     */
    private BinaryNode<E> buildUnordered(E[] arr, int low, int high) {
        if (low > high) return null;
        int mid = (low + high) / 2;
        BinaryNode<E> curr = new BinaryNode<>(arr[mid], null, null);
        curr.left = buildUnordered(arr, low, mid - 1);
        curr.right = buildUnordered(arr, mid + 1, high);
        return curr;
    }


    /**
     * Change name of tree
     * @param name new name of tree
     */
    public void changeName(String name) {
        this.treeName = name;
    }

    /**
     * Return a string displaying the tree contents as a single line
     */
    // public toString method that prints out the tree in string form
    public String toString() {
        if (root == null)
            return treeName + " Empty tree";
        else
            return treeName + "\n" + toString(root, 0);
    }
    /**
     * Return a string displaying the tree contents as a single line
     */

    /** private method called to print tree in string form with levels divided by tabs
     *
     * @param t
     * @param height
     * @return
     * Complexity is O(n log n)
     */

    private String toString(BinaryNode<E> t, int height){
        if (t == null) {
            return "";
        }
        else {
            StringBuilder sb = new StringBuilder();
            sb.append(toString(t.right, height + 1));
            for (int space = 0; space < height; space ++){
                sb.append("\t");
            }
            sb.append(t.element.toString() + "\n");
            sb.append(toString(t.left, height + 1));
            return sb.toString();
        }
    }
    public String toString2() {
        if (root == null)
            return treeName + " Empty tree";
        else
            return treeName + " " + toString2(root);
    }

    /**
     * Internal method to return a string of items in the tree in order
     * This routine runs in O(n log n)
     *
     * @param t the node that roots the subtree.
     */
    public String toString2(BinaryNode<E> t) {
        if (t == null) return "";
        StringBuilder sb = new StringBuilder();
        sb.append(toString2(t.left));
        sb.append(t.element.toString() + " ");
        sb.append(toString2(t.right));
        return sb.toString();
    }


    /**
     * The complexity of finding the deepest node is O(n)
     * @return
     */
    // public method to find the deepestNode and return its value
    public BinaryNode<E> deepestNode() {
        return deepestNode(root, 0);
    }

    // compare heights on both right and left subtree to find the deepestNode and return it
    private BinaryNode<E> deepestNode(BinaryNode<E> t, int height) {
        if (t == null) {
            return null;
        }
        t.height = height;
        if (t.left == null && t.right == null){
            return t;
        }
        BinaryNode<E> goLeft = deepestNode(t.left, height + 1);
        BinaryNode<E> goRight = deepestNode(t.right, height + 1);
        if (t.left == null && t.right != null) {
            return goRight;
        }
        if (t.right == null && t.left != null) {
            return goLeft;
        }
        if (goRight.height > goLeft.height) {
            return goRight;
        }
        return goLeft;
    }
    /**
     * The complexity of finding the flip is O(n log n)
     * reverse left and right children recursively
     */
    public void flip() {
        flip(root);
    }
    // set the left nodes equal to the right nodes and vice versa
    private void flip(BinaryNode<E>t){
    if (t == null) return;
    BinaryNode<E> temp = t.left;
    t.left = t.right;
    t.right = temp;
    flip(t.left);
    flip(t.right);
    }

    /**
     * Counts number of nodes in specified level
     * The complexity of nodesInLevel is O(2^N)
     * @param level Level in tree, root is zero
     * @return count of number of nodes at specified level
     */
    public int nodesInLevel(int level) {
        return nodesInLevel(root, level);
    }

    // use height within the node to return 1 if the node is in the level and accumulate the value to a total sum
    private int nodesInLevel(BinaryNode<E> t, int level){
        if (t == null) return 0;
        if (t.height == level) return 1;
        return nodesInLevel(t.left, level) + nodesInLevel(t.right, level);
    }
    /**
     * Print all paths from root to leaves
     * The complexity of printAllPaths is O(N)
     */
    public void printAllPaths() {
    printAllPaths(root, new ArrayList<>() );
    }

    // use an array list to hold the paths and add the root first. Do left paths first and remove the last value to have unique paths
    private void printAllPaths(BinaryNode<E> t, ArrayList<E> path){
        if (t == null) System.out.println();
        path.add(t.element);
        if (t.left == null && t.right == null) System.out.println(path);
        if (t.left != null) printAllPaths(t.left, path);
        if (t.right != null) printAllPaths(t.right, path);
        path.remove(path.size() - 1);
    }


    /**
     * Counts all non-null binary search trees embedded in tree
     *  The complexity of countBST is O(N^2)
     * @return Count of embedded binary search trees
     */
    public int countBST() {
        return countBST(root);
    }

    // Complexity O(N)
    // this method returns the count of Binary Search Trees
    private Integer countBST(BinaryNode<E> t){
        if (t == null) return 0;
        int BSTCount = 0;
        if (checkBST(t)) BSTCount ++;

        BSTCount += countBST(t.right);
        BSTCount += countBST(t.left);
        return BSTCount;
    }

    // complexity O(n)
    // this method returns whether a node is a binary search tree or not
    private boolean checkBST(BinaryNode<E> t){
        if (t == null) return false;
        if (t.left == null && t.right == null) return true;
        if (t.left == null || t.right == null) return false;
        if (t.left.element.compareTo(t.element) < 0 && t.right.element.compareTo(t.element) > 0){
            return checkBST(t.left) && checkBST(t.right);
        }
        else return false;
    }

    /**
     * Insert into a bst tree; duplicates are allowed
     * The complexity of bstInsert depends on the tree.  If it is balanced the complexity is O(log n)
     * @param x the item to insert.
     */
    public void bstInsert(E x) {

        root = bstInsert(x, root);
    }

    /**
     * Internal method to insert into a subtree.
     * In tree is balanced, this routine runs in O(log n)
     * @param x the item to insert.
     * @param t the node that roots the subtree.
     * @return the new root of the subtree.
     */
    private BinaryNode<E> bstInsert(E x, BinaryNode<E> t) {
        if (t == null)
            return new BinaryNode<E>(x, null, null);
        int compareResult = x.compareTo(t.element);
        if (compareResult < 0) {
            t.left = bstInsert(x, t.left);
        } else {
            t.right = bstInsert(x, t.right);
        }
        return t;
    }

    /**
     * Determines if item is in tree
     * @param item the item to search for.
     * @return true if found.
     */
    public boolean contains(E item) {
        return contains(item, root);
    }

    /**
     * Internal method to find an item in a subtree.
     * This routine runs in O(log n) as there is only one recursive call that is executed and the work
     * associated with a single call is independent of the size of the tree: a=1, b=2, k=0
     *
     * @param x is item to search for.
     * @param t the node that roots the subtree.
     * @return node containing the matched item.
     */
    private boolean contains(E x, BinaryNode<E> t) {
        if (t == null)
            return false;

        int compareResult = x.compareTo(t.element);

        if (compareResult < 0)
            return contains(x, t.left);
        else if (compareResult > 0)
            return contains(x, t.right);
        else {
            return true;    // Match
        }
    }
    /**
     * Remove all paths from tree that sum to less than given value
     * @param sum: minimum path sum allowed in final tree
     */
    public void pruneK(Integer sum) {
        root = pruneK(root, sum, 0);
    }

    // Complexity O(N)
    // Go through the tree and check to see if the sum of the path is greater than or equal to the requested sum and only return those paths
    private BinaryNode<E> pruneK(BinaryNode<E> t, Integer sum, int totalSum){
        if (t == null) return null;
        totalSum += (Integer) t.element;
        t.right = pruneK(t.right, sum, totalSum);
        t.left = pruneK(t.left, sum, totalSum);
        if (t.right == null && t.left == null && totalSum < sum) return null;
        return t;
    }

    /**
     * Build tree given inOrder and preOrder traversals.  Each value is unique
     * @param inOrder  List of tree nodes in inorder
     * @param preOrder List of tree nodes in preorder
     */
    public void buildTreeTraversals(E[] inOrder, E[] preOrder) {
        root = null;
    }

    /**
     * Find the least common ancestor of two nodes
     * @param leftNodeValue first node
     * @param rightNodeValue second node
     * @return String representation of ancestor
     */

    // Complexity O(N)
    // Checks element of node and compares with the low and high value until they reach the same value and return it
    private E lca(BinaryNode<E> t, E leftNodeValue, E rightNodeValue) {
    if (t == null) return null;
    if (leftNodeValue == null || rightNodeValue == null) return null;
    if (!contains(leftNodeValue)) return null;
    if (!contains(rightNodeValue)) return null;
    if(t.element.compareTo(leftNodeValue) < 0) return lca(t.right, leftNodeValue, rightNodeValue);
    else if(t.element.compareTo(rightNodeValue) > 0) return lca(t.left, leftNodeValue, rightNodeValue);
    return t.element;
    }

    public E lca(E leftNodeValue, E rightNodeValue) {
        return lca(root, leftNodeValue, rightNodeValue);
    }

    /**
     * Balance the tree
     * Complexity O(n^2)
     */
    public void balanceTree() {
        ArrayList<E> nodes = getNodeValues(root, new ArrayList<>());
        root = null;
        balanceTree(nodes, 0, nodes.size() - 1);
    }

    // Complexity O(n)
    // Uses a sorted arraylist of the nodes and inserts in the midpoint of the list and splits the left and right subtree
    private void balanceTree(ArrayList<E> nodes, int beg, int end) {
        if (beg > end) return;
        if (beg == end) {
            bstInsert(nodes.get(beg));
            return;
        }
        int mid = (end + beg) / 2;
        bstInsert(nodes.get(mid));
        balanceTree(nodes, beg, mid - 1);
        balanceTree(nodes, mid + 1, end);

    }
    // Complexity O(n)
    // creates an arraylist of nodes and sorts them from least to greatest
    private ArrayList<E> getNodeValues(BinaryNode<E> t, ArrayList<E> nodes) {
        if (t == null) return nodes;
        nodes.add(t.element);
        if (t.left == null && t.right == null) return nodes;
        if (t.left != null) getNodeValues(t.left, nodes);
        if (t.right != null) getNodeValues(t.right, nodes);
        Collections.sort(nodes);
        return nodes;
    }
    /**
     * In a BST, keep only nodes between range
     *
     * @param a lowest value
     * @param b highest value
     */
    public void keepRange(E a, E b) {
        root = keepRange(root, a, b);
    }

    // Complexity O(n^2)
    // compares value of node and keeps it if it is within the range
    private BinaryNode<E> keepRange(BinaryNode<E> t, E lowVal, E highVal) {
        if (t == null) return null;
        if (t.element.compareTo(lowVal) < 0) return keepRange(t.right, lowVal, highVal);
        else if (t.element.compareTo(highVal) > 0) return keepRange(t.left, lowVal, highVal);
        else {
            t.left = keepRange(t.left, lowVal, highVal);
            t.right = keepRange(t.right, lowVal, highVal);
            return t;
        }
    }

    // Basic node stored in unbalanced binary  trees
    public static class BinaryNode<E> {
        E element;            // The data in the node
        BinaryNode<E> left;   // Left child
        BinaryNode<E> right;// Right child
        int height = 0;

        // Constructors
        BinaryNode(E theElement) {
            this(theElement, null, null);
        }

        BinaryNode(E theElement, BinaryNode<E> lt, BinaryNode<E> rt) {
            element = theElement;
            left = lt;
            right = rt;
        }

        // toString for BinaryNode
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Node:");
            sb.append(element);
            return sb.toString();
        }

    }


}
