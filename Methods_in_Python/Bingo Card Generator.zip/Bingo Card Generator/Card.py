#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

class Card():

    def __init__(self, nId, randNumSet):  	  	  
        self.__id = nId
        randNumSet.shuffle()
        self.__arrRows = []
        self.__size = len(randNumSet)
        self.__COLUMN_NAMES = list("BINGOLARDYPEZMUX")

        # copy the randNumSet by inner lists to have increasing values within each list
        for i in range(self.__size):
            self.__arrRows.append([])
        for j in range(self.__size):
            for k in range(self.__size):
                self.__arrRows[j].append(randNumSet[k][j])

        # make the center = -1, so it can be the "FREE!" space
        if self.__size % 2 != 0:
            center = self.__size // 2
            self.__arrRows[center][center] = -1

    def getID(self):  	  	  
        """  	  	  
        Return an integer: the ID number of the card  	  	  
        """
        return self.__id

    def numberAt(self, nRow, nCol):  	  	  
        """  	  	  
        Return an integer or a string: the value in the Bingo square at (nRow, nCol)  	  	  
        """
        return self.__arrRows[nRow - 1][nCol - 1]

    def __len__(self):  	  	  
        """  	  	  
        Return an integer: the length of one dimension of the card.  	  	  
        For a 3x3 card return 3, for a 5x5 return 5, etc.  	  	  

        This method was called `getSize` in the C++ version  	  	  
        """
        return self.__size

    def __str__(self):  	  	  
        """  	  	  
        Return a string: a neatly formatted, square bingo card  	  	  

        This is basically equivalent to the `operator<<` method in the C++ version  	  	  
        """
        card = ""
        # Print Card title with ID #
        card += "\nCard #" + str(self.__id) + "\n"

        # Use a for loop to create the first row with the formatted letters from the COLUMN_NAMES list
        for i in range(self.__size):
            card += " " + format(self.__COLUMN_NAMES[i], "^5s")

          # Assign otherRow to be used in appending to card
        otherRow = "+"
        for i in range(self.__size):
            otherRow += "-----+"

        """ Use a for loop to go through the number of remaining rows and check if we're on an even row or not
            If it's even append a new line, the otherRow, and another new line
            If not, use a nested for loop and augment card by "|" and each row within 
            self.__arrRows
            Return card when finished"""

        j = 0
        for i in range(self.__size * 2 + 1):
            if i % 2 == 0:
                card += "\n" + otherRow + "\n"
            else:
                for k in range(self.__size):
                    card += "|"
                    if self.__arrRows[k][j] == -1:
                        card += "FREE!"
                    else:
                        card += format(self.__arrRows[k][j], "^5d")
                card += "|"
                j += 1
        return card

