#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

import unittest  	  	  

from Card import Card  	  	  
from RandNumberSet import RandNumberSet  	  	  


class TestCard(unittest.TestCase):  	  	  

    def setUp(self):  	  	  
        """  	  	  
        Create no fewer than 5 Card objects to test  	  	  

        Create a mixture of odd and even-sized cards  	  	  
        """
        # set up the five Card objects with differing info to be tested

        self.__firstCard = Card(1, RandNumberSet(3, 20))
        self.__secondCard = Card(2, RandNumberSet(4, 35))
        self.__thirdCard = Card(3, RandNumberSet(5, 63))
        self.__fourthCard = Card(4, RandNumberSet(6, 74))
        self.__fifthCard = Card(5, RandNumberSet(7, 99))


    def test_len(self):  	  	  
        """Assert that each card's size is as expected"""
        # find the length of the card and compare to see if it matches with what was passed to RandNumberSet
        self.assertEqual(len(self.__firstCard), 3)
        self.assertEqual(len(self.__secondCard), 4)
        self.assertEqual(len(self.__thirdCard), 5)
        self.assertEqual(len(self.__fourthCard), 6)
        self.assertEqual(len(self.__fifthCard), 7)


    def test_id(self):  	  	  
        """Assert that each card's ID number is as expected"""
        # This is self-explanatory. Call card's get ID method and verify it works
        self.assertEqual(self.__firstCard.getID(), 1)
        self.assertEqual(self.__secondCard.getID(), 2)
        self.assertEqual(self.__thirdCard.getID(), 3)
        self.assertEqual(self.__fourthCard.getID(), 4)
        self.assertEqual(self.__fifthCard.getID(), 5)

    def test_freeSquares(self):  	  	  
        """  	  	  
        Ensure that odd-sized cards have 1 "Free!" square in the center  	  	  
        Also test that even-sized cards do not have a "Free!" square by examining the 2x2 region about their centers  	  	  
        """

        """
        If odd use Equal assert test, if even use notEqual assert test and set to -1
        the odd cards only need one value to be passed to the numberAt method
        the even cards need two spots to cover all 4 spaces in the inner 2 x 2 grid
        that's what the corner variables are used for. 
        Since there's only 4 of them, use a for loop in range of 4 and check each spot 
        to make sure that they don't equal -1 
        """
        center1 = len(self.__firstCard) // 2 + 1
        self.assertEqual(self.__firstCard.numberAt(center1, center1), -1)

        corner1 = len(self.__secondCard) // 2
        corner2 = len(self.__secondCard) // 2 + 1
        for i in range(4):
            if i == 0:
                self.assertNotEqual(self.__secondCard.numberAt(corner1, corner1), -1)
            elif i == 1:
                self.assertNotEqual(self.__secondCard.numberAt(corner1, corner2), -1)
            elif i == 2:
                self.assertNotEqual(self.__secondCard.numberAt(corner2, corner1), -1)
            else:
                self.assertNotEqual(self.__secondCard.numberAt(corner2, corner2), -1)

        center3 = len(self.__thirdCard) // 2 + 1
        self.assertEqual(self.__thirdCard.numberAt(center3, center3), -1)

        corner3 = len(self.__fourthCard) // 2 - 1
        corner4 = len(self.__fourthCard) // 2
        for i in range(4):
            if i == 0:
                self.assertNotEqual(self.__fourthCard.numberAt(corner3, corner3), -1)
            elif i == 1:
                self.assertNotEqual(self.__fourthCard.numberAt(corner3, corner4), -1)
            elif i == 2:
                self.assertNotEqual(self.__fourthCard.numberAt(corner4, corner3), -1)
            else:
                self.assertNotEqual(self.__fourthCard.numberAt(corner4, corner4), -1)

        center5 = len(self.__fifthCard) // 2 + 1
        self.assertEqual(self.__fifthCard.numberAt(center5, center5), -1)



    def test_no_duplicates(self):  	  	  
        """Ensure that Cards do not contain duplicate numbers"""  	  	  
        # Hint: look at how TestRandNumberSet.test_noDuplicates works

        # Use a set, find each value in the Card and make sure set doesn't already contain the value

        testCard = set()

        for row in range(len(self.__firstCard)):
            for col in range(len(self.__firstCard)):
                value1 = self.__firstCard.numberAt(row, col)
                if value1 in testCard:
                    self.assertTrue(False)
                else:
                    testCard.add(self.__firstCard)

        for row in range(len(self.__secondCard)):
            for col in range(len(self.__secondCard)):
                value2 = self.__secondCard.numberAt(row, col)
                if value2 in testCard:
                    self.assertTrue(False)
                else:
                    testCard.add(self.__secondCard)

        for row in range(len(self.__thirdCard)):
            for col in range(len(self.__thirdCard)):
                value3 = self.__thirdCard.numberAt(row, col)
                if value3 in testCard:
                    self.assertTrue(False)
                else:
                    testCard.add(self.__thirdCard)

        for row in range(len(self.__fourthCard)):
            for col in range(len(self.__fourthCard)):
                value4 = self.__fourthCard.numberAt(row, col)
                if value4 in testCard:
                    self.assertTrue(False)
                else:
                    testCard.add(self.__fourthCard)

        for row in range(len(self.__fifthCard)):
            for col in range(len(self.__fifthCard)):
                value5 = self.__fifthCard.numberAt(row, col)
                if value5 in testCard:
                    self.assertTrue(False)
                else:
                    testCard.add(self.__fifthCard)


if __name__ == '__main__':  	  	  
    unittest.main()  	  	  
