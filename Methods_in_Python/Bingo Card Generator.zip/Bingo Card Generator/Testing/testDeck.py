#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

import unittest  	  	  
from Deck import Deck


class TestDeck(unittest.TestCase):  	  	  
    def setUp(self):  	  	  
        """  	  	  
        Create no fewer than 5 Deck objects to test  	  	  

        Create at least one Deck with the minimum number of Cards  	  	  
        Create at least one Deck with the maximum number of Cards  	  	  
        Create a mixture of large and small cards  	  	  
        """
        # Here are the 5 Deck objects with varying sizes

        self.__firstDeck = Deck(3, 2, 19)
        self.__secondDeck = Deck(16, 2, 512)
        self.__thirdDeck = Deck(6, 8192, 74)
        self.__fourthDeck = Deck(11, 200, 50)
        self.__fifthDeck = Deck(8, 37, 240)



    def test_len(self):  	  	  
        """  	  	  
        Ensure that Decks contain the expected number of cards  	  	  
        """
        # compare length of the Deck with the cardNum parameter of the Deck object
        self.assertEqual(len(self.__firstDeck), 2)
        self.assertEqual(len(self.__secondDeck), 2)
        self.assertEqual(len(self.__thirdDeck), 8192)
        self.assertEqual(len(self.__fourthDeck), 200)
        self.assertEqual(len(self.__fifthDeck), 37)

    def test_card(self):  	  	  
        """  	  	  
        Ensure that specific Cards can be accessed from within a Deck  	  	  

        Assert that requesting Cards at invalid indexes fails  	  	  
        """  	  	  
        # Make sure the ID number of the card is equal to the Card.getID()

        self.assertEqual(self.__firstDeck[0].getID(), 1)
        with self.assertRaises(IndexError):
            x = self.__firstDeck[3]
        self.assertEqual(self.__secondDeck[0].getID(), 1)
        with self.assertRaises(IndexError):
            x = self.__secondDeck[3]
        self.assertEqual(self.__thirdDeck[841].getID(), 842)
        with self.assertRaises(IndexError):
            x = self.__thirdDeck[8193]
        self.assertEqual(self.__fourthDeck[9].getID(), 10)
        with self.assertRaises(IndexError):
            x = self.__fourthDeck[201]
        self.assertEqual(self.__fifthDeck[36].getID(), 37)
        with self.assertRaises(IndexError):
            x = self.__fifthDeck[38]

if __name__ == '__main__':  	  	  
    unittest.main()  	  	  
