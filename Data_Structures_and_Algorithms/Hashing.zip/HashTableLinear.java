public class HashTableLinear extends HashTable{

    public HashTableLinear(){
        this(DEFAULT_TABLE_SIZE,50);
        load = 50;
        doClear();
        debug = false;
    }
    public HashTableLinear(int size, int load){
        allocateArray(size);
        this.load = load;
        doClear();
        debug = false;
    }
    @Override
    public int findPos(String x) {
        int offset = 1;
        int currentPos = myhash(x);
        int thisProbe = 1;
        probeCt++;
        while (array[currentPos] != null &&
                !array[currentPos].element.equals(x)) {
            currentPos += offset; // Compute ith probe
            probeCt++;
            thisProbe++;
            if (currentPos >= array.length)
                currentPos -= array.length;
        }
        if (thisProbe > maxProbeCt){
            maxProbeCt=thisProbe;
        }
        return currentPos;
    }
}
