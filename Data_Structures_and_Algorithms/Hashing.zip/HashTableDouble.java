public class HashTableDouble extends HashTable{
    public HashTableDouble(){
        this(DEFAULT_TABLE_SIZE,50);
        load = 50;
        doClear();
        debug = false;
    }
    public HashTableDouble(int size, int load){
        allocateArray(size);
        this.load = load;
        doClear();
        debug = false;
    }
//    public int secondHash(String x){
//        int hashVal = x.hashCode();
//        hashVal %= 9;
//        if (hashVal < 0)
//            hashVal += 9;
//        return hashVal;
//    }
    @Override
    public int findPos(String x) {
        int currentPos = myhash(x);
        int offset = x.hashCode() % 19 + 3;
        int thisProbe=1;
        probeCt++;
        while (array[currentPos] != null &&
                !array[currentPos].element.equals(x)) {
            currentPos += offset; // Compute ith probe
            probeCt++;
            thisProbe++;
            if (currentPos >= array.length)
                currentPos -= array.length;
        }
        if (thisProbe > maxProbeCt){
            maxProbeCt=thisProbe;
        }
        return currentPos;
    }
}
