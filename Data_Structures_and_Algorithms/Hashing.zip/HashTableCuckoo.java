import java.io.BufferedReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

public class HashTableCuckoo implements HashTableInterface{
    @Override
    public void insertAll(BufferedReader sc, int size) {
        DecimalFormat df = new DecimalFormat("0.00");
        try {
            probeCt = 0;
            maxProbeCt=0;
            insertCt = 0;
            rehashCt = 0;
            String w;
            while (insertCt <= size && (w = (String) sc.readLine()) != null) {
                insert(w);
                insertCt++;
            }
            System.out.println("*** FirstTableSize " + array.length + " Inserted " + insertCt +
                    " load factor (" + load + "%) probes " + probeCt + " Average Cost " + df.format(probeCt / (float) insertCt) + " maxCost = " + maxProbeCt);
            if (rehashCt > 0) System.out.println(" Rehashed " + rehashCt);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void findAll(BufferedReader sc, String msg) {
        try {
            DecimalFormat df = new DecimalFormat("0.00");
            probeCt = 0;
            maxProbeCt=0;
            int ct = 0;
            int foundCt = 0;
            rehashCt = 0;
            String w;
            while ((w = (String) sc.readLine()) != null) {
                ct++;
                if (find(w)) foundCt++;
                else {
                    if (debug) {
                        System.out.println(" Not Found '" + w + "' at line " +
                                ct);
                    }
                }
            }
            System.out.println(msg + " Looked for " + ct + " Found " + foundCt + " probes " + probeCt +
                    " Average Cost " + df.format(probeCt / (float) ct)+ " maxCost = " + maxProbeCt);
            if (rehashCt > 0) System.out.println(" Rehashed " + rehashCt);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public java.lang.String toString(int limit) {
        StringBuilder sb = new StringBuilder();
        int ct = 0;
        for (int i = 0; i < array.length && ct < limit; i++) {
            if (array[i] != null) {
                sb.append(i + ": " + array[i] + "\n");
                ct++;
            }
        }
        return sb.toString();
    }
    public HashTableCuckoo(){
        this(DEFAULT_TABLE_SIZE,50);
        load = 50;
        doClear();
        debug = false;
    }
    public HashTableCuckoo(int size, int load){
        allocateArray(size);
        allocateArray2(size);
        this.load = load;
        doClear();
        doClear2();
        debug = false;
    }

    public boolean find(String x) {
        int thisProbe = 0;
        int firstPos = myhash(x);
        int secondPos = secondHash(x);
        probeCt++;
        thisProbe++;
        if (thisProbe > maxProbeCt) maxProbeCt = thisProbe;
        if (array[firstPos] != null && array[firstPos].equals(x)) return true;

        probeCt++;
        thisProbe++;
        if (thisProbe > maxProbeCt) maxProbeCt = thisProbe;
        if (array2[secondPos] != null && array2[secondPos].equals(x)) return true;

        return false;
    }
    public void insert(String x) {
// Insert x as active
        if (find(x)) return;
        currentActiveEntries++;
        int thisProbe = 0;
        for (int i = 0; i < 40; i++) {
            int currentPos = myhash(x);
            if (array[currentPos] == null) {
                array[currentPos] = x;
                if (thisProbe > maxProbeCt) maxProbeCt = thisProbe;
                return;
            }
            probeCt++;
            thisProbe++;
            String temp = array[currentPos];
            array[currentPos] = x;
            int secondPos = secondHash(temp);
            if (array2[secondPos] == null){
                array2[secondPos] = temp;
                if (thisProbe > maxProbeCt) maxProbeCt = thisProbe;
                return;
            }
            probeCt++;
            thisProbe++;
            x = array2[secondPos];
            array2[secondPos] = temp;
        }
// Rehash; see Section 5.5
            rehash();
            insert(x);
    }

//    public boolean insert2(String x) {
//// Insert x as active
//        int currentPos = findPos2(x);
//        if (isActive2(currentPos))
//            return false;
//        array2[currentPos] = new HashTable.HashEntry(x, true);
//        currentActiveEntries++;
//// Rehash; see Section 5.5
//        if (++occupiedCt > array2.length * load/100) {
//            rehash2();
//            rehashCt++;
//        }
//        return true;
//    }


    public int myhash(String x) {
        if (x == null) return 0;
        int hashVal = x.hashCode();
        hashVal %= array.length;
        if (hashVal < 0)
            hashVal += array.length;
        return hashVal;
    }

    public int secondHash(String x){
        int hashVal = x.hashCode();
        hashVal %= 13 + 5;
        if (hashVal < 0){
            hashVal += array.length;
        }
        return hashVal;
    }

    protected int findPos(String x) {
        int currentPos = myhash(x);
        int secondPos = secondHash(x);
        int thisProbe=1;
            if(array[currentPos] != null && array[currentPos].equals(x)) {
                return currentPos;
            }
            probeCt++;
            thisProbe++;
            if (array2[secondPos] != null && array2[secondPos].equals(x)){
                return secondPos;
            }
            probeCt++;
            thisProbe++;
            if (thisProbe > maxProbeCt){
                maxProbeCt=thisProbe;
            }
        return currentPos;
    }


//    public boolean isActive2(int currentPos) {
//        return array2[currentPos] != null && array2[currentPos].isActive;
//    }

    public void rehash() {
        String[] oldArray = array;
// Create a new double-sized, empty table
        allocateArray(2 * oldArray.length);
        occupiedCt = 0;
        currentActiveEntries = 0;
// Copy table over
        for (String entry : oldArray) {
            if (entry != null) insert(entry);
        }
        String[] oldArray2 = array2;
// Create a new double-sized, empty table
        allocateArray2(2 * oldArray2.length);
        occupiedCt = 0;
        currentActiveEntries = 0;
// Copy table over
        for (String entry : oldArray2) {
            if (entry != null)
                insert(entry);
        }
        rehashCt++;
    }

    public void rehash2() {
        String[] oldArray = array2;
// Create a new double-sized, empty table
        allocateArray2(2 * oldArray.length);
        occupiedCt = 0;
        currentActiveEntries = 0;
// Copy table over
        for (String entry : oldArray)
            if (entry != null)
                insert(entry);
    }

    public static final int DEFAULT_TABLE_SIZE = 101;
    public String[] array; // The array of elements
    public String[] array2;
    public int occupiedCt; // The number of occupied cells: active or deleted
    public int currentActiveEntries; // Current size
    public int probeCt;
    public int maxProbeCt;
    public int insertCt;
    public int rehashCt;
    public int load;
    public boolean debug;

    public void doClear(){
        occupiedCt = 0;
        Arrays.fill(array, null);
    }

    public void doClear2(){
        occupiedCt = 0;
        Arrays.fill(array2, null);
    }
    public void allocateArray (int arraySize){
        array = new String[nextPrime(arraySize)];
        doClear();
    }

    public void allocateArray2 (int arraySize){
        array2 = new String[nextPrime(arraySize)];
        doClear2();
    }
    public static int nextPrime(int n){
        if (n % 2 == 0)
            n++;
        for (; !isPrime(n); n += 2) {
            ;
        }
        return n;
    }
    public static boolean isPrime(int n){
        if (n == 2 || n == 3) return true;
        if (n == 1 || n % 2 == 0) return false;
        for (int divisor = 3; divisor * divisor <= n; divisor += 2)
            if (n % divisor == 0) return false;
        return true;
    }
}
