# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh


# Requirements for Assignment 4
1. Make sure all keys are displayed for the user
2. Show when each key is pressed down
3. Change keyboard when either left, right, or both shift buttons are held
4. Make the letters in the prompt light and color in when the letter is entered 
5. Underline the next character in the prompt 
6. Highlight the border of the correct key red for the user to click until it is clicked
7. Log the next key into the console with a counter that increments until that key is pressed
8. When the text prompt is finished, immediately load the next prompt for the user to complete. 
9. Make sure no errors occur when incorrect keys are entered, don't change until the correct key is entered
10. When multiple keys are pressed, each key should show that it is pressed or not pressed, based on user input 