import React, { useState, useEffect } from 'react'; 

export const Keyboard_Tutor = () => {
  const normalKeyboardLayout = [
    ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='],
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', "'"],
    [{ label: 'Shift', className: 'keyboard-key shift'}, 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', { label: 'Shift', className: 'keyboard-key shift'}],
    [{ label: 'Space', className: 'keyboard-key space-bar'}]
  ];

  const shiftedKeyboardLayout = [
    ['~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+'],
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '|'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"'],
    [{ label: 'Shift', className: 'keyboard-key shift'}, 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', { label: 'Shift', className: 'keyboard-key shift'}],
    [{ label: 'Space', className: 'keyboard-key space-bar'}]
  ];
  
  const practicePhrases = [
    "The quick brown fox jumps over the lazy dog. This is a classic pangram.",
    "Jinxed wizards pluck ivy from the big quilt.",
    "Pack my box with five dozen liquor jugs.",
    "To give anything less than your best is to sacrifice the gift.",
    "You miss 100% of the shots you don't take.",
    "Find a job you enjoy doing, and you will never have to work a day in your life.",
    "To win the game is great, to play the game is greater, to love the game is greatest of all."
];

  const [shiftPressed, setShiftPress] = useState(false);
  const [keyboardLayout, setKeyboardLayout] = useState(normalKeyboardLayout);
  const [presentPhrasePosition, setPresentPhrasePosition] = useState(0);
  const [leftoverPhrase, setLeftoverPhrase] = useState(practicePhrases[presentPhrasePosition]);
  const [finishedPhrase, setFinishedPhrase] = useState('');

  useEffect(() => {
    const handleKeyPressed = (e) => {
      const key = e.key;
      if (key === "Shift") {
        setShiftPress(true);
        setKeyboardLayout(shiftedKeyboardLayout);
        const shiftKeys = document.querySelectorAll(".shift");
        shiftKeys.forEach((shiftKey) => {
          shiftKey.classList.add("active");
        });
      }
      else if (key === " ") {
        const spaceBarKey = document.querySelector(".space-bar");
        if (spaceBarKey) {
          spaceBarKey.classList.add("active");
        }
        handleSpaceKey();
      }
      else {
        const markedChar = leftoverPhrase[0];
        if (markedChar && markedChar === key) {
            setFinishedPhrase(finishedPhrase + markedChar);
            setLeftoverPhrase(leftoverPhrase.slice(1));
            if (leftoverPhrase.length === 1) {
              setPresentPhrasePosition((previousPosition) => (previousPosition + 1) % practicePhrases.length);
              setFinishedPhrase('');
              setLeftoverPhrase(practicePhrases[presentPhrasePosition + 1] % practicePhrases.length);
            }
        }
        const keyboardKey = document.querySelector(`.keyboard-key[data-key="${key}"]`);
        if (keyboardKey) {
          keyboardKey.classList.add("active");
        }
      }
    };

    const handleKeyUnpressed = (e) => {
        const key = e.key;
      if (key === "Shift") {
        setShiftPress(false);
        setKeyboardLayout(normalKeyboardLayout);

        const shiftKeys = document.querySelectorAll(".shift");


        shiftKeys.forEach((shiftKey) => {
          shiftKey.classList.remove("active");
        });
      } 
      else if (key === " ") {
        
        const spaceBarKey = document.querySelector(".space-bar");

        if (spaceBarKey) {
          spaceBarKey.classList.remove("active");
        }
      } else {
        
        const keyboardKey = document.querySelector(`.keyboard-key[data-key="${key}"]`);

        if (keyboardKey) {
          keyboardKey.classList.remove("active");
        }
      }
    };

    const handleSpaceKey = () => { 
      if (leftoverPhrase[0] === " ") {
        setFinishedPhrase(finishedPhrase + ' ');  
        setLeftoverPhrase(leftoverPhrase.slice(1)); 

        if (leftoverPhrase.length === 1) {
          setPresentPhrasePosition((previousPosition) => (previousPosition + 1) % practicePhrases.length); 
          setFinishedPhrase('');
          setLeftoverPhrase(practicePhrases[(presentPhrasePosition + 1) % practicePhrases.length]); 
        }
      }
    };

    window.addEventListener("keydown", handleKeyPressed);
    window.addEventListener("keyup", handleKeyUnpressed);

    return () => {
      window.removeEventListener("keydown", handleKeyPressed);
      window.removeEventListener("keyup", handleKeyUnpressed);
    };

    }, [leftoverPhrase, presentPhrasePosition, shiftPressed]);

    const makeKeyboard = () => {

      return keyboardLayout.map((row, rowPosition) => 
    <div className="keyboard-row" key={rowPosition}>
      {row.map((key, keyPosition) => {
        const isSpaceMarked = leftoverPhrase[0] === " " && key.label === "Space";
        const isShiftMarked = leftoverPhrase[0] && leftoverPhrase[0] === leftoverPhrase[0].toUpperCase() && key.label === "Shift";
        const isKeyMarked = leftoverPhrase[0] === key || isSpaceMarked || isShiftMarked;
        return (
          typeof key === "object" ?

          <div className={`${key.className} ${isSpaceMarked || isShiftMarked ? "highlighted" : ""}`} key={keyPosition}>
            {key.label}
          </div> : 
            <div className={`keyboard-key ${isKeyMarked ? "highlighted" : ""}`} key={keyPosition} data-key={key}>
              {key}
            </div>

        );

       })}
    </div>
    );

 };

  return (
    <main className="content">
      <div className="phrase">
        <span className="typed-phrase">{finishedPhrase}</span>
        <span className="pointer">{leftoverPhrase[0]}</span>
        {leftoverPhrase.substring(1)}
      </div>
      <div className="keyboard">
        {makeKeyboard()}
      </div>
    </main>
  );
};

export default Keyboard_Tutor;