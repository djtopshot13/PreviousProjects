import { Keyboard_Tutor } from "./Keyboard_Tutor";


function App() {

  return (
      < Keyboard_Tutor />
  )
};

export default App
