# Fractal Visualizer User Manual

*   This is the **user manual**, not the **programmer's manual**
    *   Keep your instructions at a user-friendly level.
*   Explain how to run the program
    *   What is the name of the main program file?
    *   What command-line arguments are needed?
*   What output does the program produce?
    *   What is shown when the program works correctly?
    *   What is shown when an error is encountered
    *   Provide examples of both!

### Welcome!
Welcome to the Fractal Generator! We hope you enjoy the product provided and that the instructions below
    are clear and concise. 
We are certain that you will find all you need to ensure the program functions according to your expectations.

### Input 
The name of the main program file is main.py within the src directory. 
For the command-line argument from the default location, you simply have to type python src/main.py and a fractal name. 
    Here is an example: python src/main.py peacock

### Output 
1. Correct Output
With the example statement above, (python src/main.py peacock) the program will work correctly and draw out the peacock fractal picture. 
It will also save an image file under the fractal name.png, so in this instance it'd be peacock.png
The program will print a rendering statement, a loading bar that goes from 0 to 100%, the total time took to finish, 
    which picture it wrote and to close the image window to exit the program. 

Rendering peacock fractal
\[100%=================================]
Done in 9.331 seconds! 
Wrote picture peacock.png  
Close the image window to exit the program  

2. Forgetting a Fractal Name
If you forget to type a fractal name in the command-line argument, the program will ask for a fractal name in the argument.
It will also print a list below of all the fractal names you can choose from that the program can work with.

Ex. python src/main.py
This example statement will produce this output:

Please provide the name of a fractal as an argument
phoenix
peacock
monkey-knife-fight
shrimp-cocktail
elephants
leaf
mandelbrot
mandelbrot-zoomed
seahorse
spiral0  
spiral1
starfish

3. Invalid Fractal Name
If a fractal name isn't all in lowercase or isn't included in the list, the program will ask for a valid fractal name.

Ex. python src/main.py Phoenix
This example statement will produce this output:

ERROR: Peacock is not a valid fractal                                                                                   
Please choose one of the following:
phoenix
peacock
monkey-knife-fight
shrimp-cocktail
elephants
leaf
mandelbrot
mandelbrot-zoomed
seahorse
spiral0  
spiral1
starfish


