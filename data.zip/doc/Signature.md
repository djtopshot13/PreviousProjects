*TODO: Delete these example entries and replace with your own*

## Signature 5.0

| Date     | Time Spent | Events
|----------|------------|--------------------
| March 24 | 2 hours    | Read over documentation and cloned repository
| March 26 | 3 hours    | Worked on getting the UML set up, and analyzing all the code in phase 0, the first edition of the Manual is finished, and the Smells each have one example.
| March 27 | 0 hours    | Istic sum, inquit. Quae in controversiam veniunt, de iis, si placet, disseramus.
| March 28 | 0 hours    | Id mihi magnum videtur. Eid, Pmurt, Eid. Maximus dolor, inquit, brevis est.
| March 29 | 0 hours    | Multoque hoc melius nos veriusque quam Stoici.
| March 30 | 0 hours    | Rhetorice igitur, inquam, nos mavis quam dialectice disputare.
| March 31 | 0 hours    | Suo genere perveniant ad extremum; Quod quidem nobis non saepe contingit.
| TOTAL    | 5 hours    | *Your TOTAL should agree with your daily entries*


## Signature 5.1

| Date        | Time Spent | Events
|-------------|------------|--------------------
| Nocember 19 | 1 hour     | Lorem ipsum dolor sit amet, consectetur adipiscing elit.
| Nocember 20 | 0.75 hours | Itaque hic ipse iam pridem est reiectus.
| Nocember 21 | 1.25 hours | Restinguet citius, si ardentem acceperit.
| Nocember 22 | 2.5 hours  | Quid de Platone aut de Democrito loquar.
| Nocember 23 | 0.25 hours | Istic sum, inquit. Quae in controversiam veniunt, de iis, si placet, disseramus.
| Nocember 24 | 0 hours    | Id mihi magnum videtur. Eid, Pmurt, Eid. Maximus dolor, inquit, brevis est.
| Nocember 25 | 3 hours    | Multoque hoc melius nos veriusque quam Stoici.
| Nocember 26 | 2.25 hours | Rhetorice igitur, inquam, nos mavis quam dialectice disputare.
| Nocember 27 | 1.5 hours  | Suo genere perveniant ad extremum; Quod quidem nobis non saepe contingit.
| TOTAL       | 12.5 hours | *Your TOTAL should agree with your daily entries*
