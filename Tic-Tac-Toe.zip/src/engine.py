# import statements for the engine function to get the majority of the game up and running
# Global constant variable CPU_DELAY to be used in function game and cpu_turn

from interface import get_human_move, color, red, green, yellow, cyan
from util import make_board, clear, home
from time import sleep
CPU_DELAY = 0.75

# this function returns a tuple of all the empty/non-played on spots on the board

def open_cells(b):
    """ Returns a tuple of the unmarked cells in a Tic-Tac-Toe board """
    cs = []
    for p in b:
        if type(p) is int:
            cs.append(p)
    return tuple(cs)

# this function shows the board with the numbers or string 'X' or 'O' in the corresponding spot

def show(board):
    """
    Display the Tic-Tac-Toe board on the screen, in color

    When the optional parameter 'clear' is True, clear the screen before printing the board
    """
    if board:
        print(" {} | {} | {}\n---+---+---\n {} | {} | {}\n---+---+---\n {} | {} | {}\n".format(
            color(board[0]), color(board[1]), color(board[2]),
            color(board[3]), color(board[4]), color(board[5]),
            color(board[6]), color(board[7]), color(board[8])))


    # Accepts: a game board (tuple), position (integer), and a player's identity ("X" or "O")
    # Return a copy of the board with that player's mark put into the requested
    # position, iff a player's mark isn't already present there.

    # Otherwise, return False


def place(board, position, player):

    if not 1 <= position <= 9:
        # player requested an out-of-bounds position
        return False

    # convert position into (row, col) coordinates
    #row, col = pos_to_rowcol(position)

    if board[position - 1] != 'X' and board[position - 1] != 'O':
        # construct a brand new board
        new = []
        for p in board:
            new.append(p)
        new[position - 1] = player
        # Always maintain the board as a tuple to guarantee that it
        # can never be accidentally modified
        return tuple(new)
    else:
        return False

# Determines if the game has been one by having 3 of the same symbol in a row

def horizontal_winner(board):
    """
    Determines which a player has won a game with a horizontal triple.
    Input: a 2D game board.
    Return: 'X' or 'O' when there is a winner, or False when no player has 3 in
    a horizontal row

    The code we arrived at borders on being too clever for our own good, and
    bears some explanation.

    The first line checks whether the three cells in the top row are all the
    same.  This is ONLY true when the same player has played their mark there.
    The `and` conjunction at the end of each sub-clause might look useless, but
    is very important.  It returns the letter of the winning player:
        https://docs.python.org/3/reference/expressions.html#boolean-operations

    Without it, this function could only return 'True' or 'False', merely
    indicating that SOMEBODY won the game instead of stating who the winner is.
    """
    return (board[0] == board[1] == board[2] and board[0]) \
        or (board[3] == board[4] == board[5] and board[3]) \
        or (board[6] == board[7] == board[8] and board[6])

# Determines if the game has been one by 3 of the same symbol in a column

def vertical_winner(board):
    """
    Determines which a player has won a game with a vertical triple
    """
    return (board[0] == board[3] == board[6] and board[0]) \
        or (board[1] == board[4] == board[7] and board[1]) \
        or (board[2] == board[5] == board[8] and board[2])

# Determines if the game has been one by 3 of the same symbol in a diagonal

def diagonal_winner(board):
    """
    Determines which a player has won a game with a diagonal triple
    """
    return (board[0] == board[4] == board[8] and board[0]) \
        or (board[2] == board[4] == board[6] and board[2])

# Returns True if the game has been won any of the three ways the game can be won returns the symbol and True

def winner(board):
    """
    Returns the winner of the game (if any), or False when there is no winner
    """
    return horizontal_winner(board) or vertical_winner(board) or diagonal_winner(board)

# This function automates the user's order of play by using get_human_move
# It also prints error statements and prompts input again from user if invalid input is given

def human_turn(board, letter):
    """
    Return False if the game is over,
           True to keep playing
    """
    while True:
        choice = get_human_move(board, letter)
        if not choice:
            return False
        new_board = place(board, choice, letter)
        if not new_board:
            if letter == 'X':
                print(red("You can't play at {}!".format(choice)))
            else:
                print(green("You can't play at {}!".format(choice)))
        else:
            return new_board

# Uses cpu strategy, board, letter and determines what color to print statements for the CPU based on what letter it is marking
# Returns the place function with the CPU's new move

def cpu_turn(board, letter, strategy_oracle, verbose=True):
    if letter == "X":
        color = red
    else:
        color = green
    if verbose:
        print(color("CPU {} is taking its turn...".format(letter)), end=' ', flush=True)
    sleep(CPU_DELAY)
    choice = strategy_oracle(board)
    if verbose:
        print(color("playing on {}\n".format(choice)))
    return place(board, choice, letter)

# This function pits two CPUs against one another using optimal strategy. Always results in a draw
# Alternates the cpu_turn function

def cpu_vs_cpu(strategy_oracle):
    """Game mode 0: run the game between two CPU opponents"""
    board = make_board()
    while True:
        show(board)
        board = cpu_turn(board, 'X', strategy_oracle)
        if not keep_playing(board):
            break
        show(board)
        board = cpu_turn(board, 'O', strategy_oracle)
        if not keep_playing(board):
            break
    show(board)

# Combines cpu_turn and human_turn, with cpu as 'X' and human as 'O'

def cpu_vs_human(strategy_oracle):
    board = make_board()
    while True:
        show(board)
        board = cpu_turn(board, 'X', strategy_oracle)
        if not keep_playing(board):
            break
        board = human_turn(board, 'O')
        if not keep_playing(board):
            break
    show(board)


# uses human_turn and checks to see if game is done or not until the game is finished.

def human_vs_human():
    board = make_board()
    while True:
        board = human_turn(board, 'X')
        if not keep_playing(board):
            break
        board = human_turn(board, 'O')
        if not keep_playing(board):
            break
    show(board)

# Combines cpu_turn and human_turn, with human as 'X' and cpu as 'O'

def human_vs_cpu(strategy_oracle):
    board = make_board()
    while True:
        board = human_turn(board, 'X')
        if not keep_playing(board):
            break
        show(board)
        board = cpu_turn(board, 'O', strategy_oracle)
        if not keep_playing(board):
            break
    show(board)


# Same as cpu_vs_cpu, but with prin statements and a loop of tic tac toe games that speed up over time

def game(strategy_oracle):
    global CPU_DELAY
    clear()
    print(cyan("GREETINGS PROFESSOR FALKEN\n"))
    sleep(CPU_DELAY)
    print(cyan("SHALL WE PLAY A GAME?\n"))
    sleep(CPU_DELAY * 2)
    orig_delay = CPU_DELAY
    clear()
    for _ in range(40):
        board = make_board()
        clear()
        while True:
            if CPU_DELAY > 0.025:
                CPU_DELAY *= 0.95
            home()
            show(board)
            board = cpu_turn(board, 'X', strategy_oracle, verbose=False)
            if not keep_playing(board):
                break
            home()
            show(board)
            board = cpu_turn(board, 'O', strategy_oracle, verbose=False)
            if not keep_playing(board):
                break
        clear()
        show(board)
        keep_playing(board)
        sleep(CPU_DELAY)
    CPU_DELAY = orig_delay
    sleep(CPU_DELAY)
    print(cyan("A STRANGE GAME.\n"))
    sleep(CPU_DELAY * 2)
    print(cyan("THE ONLY WINNING MOVE IS NOT TO PLAY.\n"))
    sleep(CPU_DELAY * 2)
    print(cyan("HOW ABOUT A NICE GAME OF CHESS?\n"))
    sleep(CPU_DELAY * 5)

# Checks to see if board is full and returns a boolean

def full(board):
    return open_cells(board) == ()

#     Accepts a board or False as input
#            board: take another turn
#            False: the user has requested to quit the game
#     Return False if the game is over for any reason (quitting, win, lose or draw),
#            or a new board to keep playing

def keep_playing(board):

    if not board:
        return False
    who = winner(board)
    if who == "X":
        print(red("\n{} is the winner!\n".format(who)))
        return False
    elif who == "O":
        print(green("\n{} is the winner!\n".format(who)))
        return False
    elif full(board):
        print(yellow("\nStalemate.\n"))
        return False
    else:
        return board