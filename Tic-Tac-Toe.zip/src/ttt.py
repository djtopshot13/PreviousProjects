#!/usr/bin/python3  	  	  

#                         ,  	  	  
#                        (o)<  DuckieCorp Software License  	  	  
#                   .____//  	  	  
#                    \ <' )   Copyright (c) 2023 Erik Falor  	  	  
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  	  	  
#         TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION  	  	  
#  	  	  
# You may reproduce and distribute copies of the Work in any medium,  	  	  
# with or without modifications, provided that You meet the following  	  	  
# conditions:  	  	  
#  	  	  
#   (a) You must give any other recipients of the Work a copy of this  	  	  
#       License; and  	  	  
#   (b) You must cause any modified files to carry prominent notices  	  	  
#       stating that You changed the files; and  	  	  
#   (c) You must retain, in the Source form of the files that You  	  	  
#       distribute, all copyright, patent, trademark, and attribution  	  	  
#       notices from the Source form of the Work; and  	  	  
#   (d) You do not misuse the trade names, trademarks, service marks,  	  	  
#       or product names of the Licensor, except as required for  	  	  
#       reasonable and customary use of the source files.  	  	  

# Here are the import statements needed to run the game for the user to play/spectate.

from engine import cpu_vs_cpu, human_vs_cpu, cpu_vs_human, human_vs_human, game
from interface import player_select
from util import logo
from ai import strategy_oracle

# This is the if statement that leads into the while loop that puts the game into main menu mode for the user.
# It has all game mode options and even has a print function thanking the user when they choose to exit the game.

if __name__ == '__main__':
    while True:
        logo()
        mode = player_select()
        if mode == 0:
            cpu_vs_cpu(strategy_oracle)
        elif mode == 1:
            human_vs_cpu(strategy_oracle)
        elif mode == 2:
            cpu_vs_human(strategy_oracle)
        elif mode == 3:
            human_vs_human()
        elif mode == 4:
            game(strategy_oracle)
        else:
            break
    print("Thanks for playing!")
