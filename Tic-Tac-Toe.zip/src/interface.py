# No import statements necessary.
# The show function is what allows the make-board function to be presented in reality to the user.

def show(board):
    """
    Display the Tic-Tac-Toe board on the screen, in color

    When the optional parameter 'clear' is True, clear the screen before printing the board
    """
    if board:
        print(" {} | {} | {}\n---+---+---\n {} | {} | {}\n---+---+---\n {} | {} | {}\n".format(
            color(board[0]), color(board[1]), color(board[2]),
            color(board[3]), color(board[4]), color(board[5]),
            color(board[6]), color(board[7]), color(board[8])))

# This function accounts for very bad input from the human and navigates the user to a point where the game will always continue
# no matter what input the user tries to give to break the game. It returns the choice number to be used in the human_turn function.

def get_human_move(board, letter):
    """
    Ask a human which move to take, or whether they want to quit.
    Perform rudimentary input validation, repeating the prompt until a valid
    input is given:
     * Integers must be in the range of [1..9] (whether it represents a legal
       move is to be handled by the caller)
     * Strings beginning with 'Q' or 'q' quit the game

    Return an integer [1..9] to indicate the move to take, or False to quit the game
    """
    while True:
        show(board)
        choice = input("Place your '{}' (or 'Q' to quit)> ".format(color(letter)))
        if not choice.isdigit():
            if choice.lower().startswith('q'):
                return False
            else:
                print("I don't understand '{}', try again!\n".format(choice))
        else:
            choice = int(choice)
            if not 0 < choice < 10:
                print("Numbers must be between 1 and 9, try again!\n")
            else:
                return choice

# player_select is what helps the ttt.py file for loop to function with the print functions for the game modes
# and it gets the users input to start a game mode, print an error statement for invalid input or to quit.

def player_select():
    while True:
        print("0)", red("X"),   cyan("CPU  "), "vs.", green("O"), cyan("CPU"))
        print("1)", red("X"), yellow("Human"), "vs.", green("O"), cyan("CPU"))
        print("2)", red("X"),   cyan("CPU  "), "vs.", green("O"), yellow("Human"))
        print("3)", red("X"), yellow("Human"), "vs.", green("O"), yellow("Human"))
        p = input("Choose game mode [0-3] or Q to quit > ")
        if p == "0" or p == "1" or p == "2" or p == "3":
            return int(p)
        elif p.lower() == "joshua":
            return 4
        elif p.lower().startswith('q'):
            return p
        else:
            print("\nInvalid selection!\n")

# red function to print strings in red color

def red(s):
    return "\x1b[1;31m{}\x1b[0m".format(s)

# green function to print strings in green color

def green(s):
    return "\x1b[1;32m{}\x1b[0m".format(s)

# yellow function to print strings in yellow color

def yellow(s):
    return "\x1b[1;33m{}\x1b[0m".format(s)

# cyan function to print strings in cyan color

def cyan(s):
    return "\x1b[1;36m{}\x1b[0m".format(s)

# color function to return red for 'X' strings, green for 'O' strings, yellow for everything else

def color(s):
    if s == 'X':
        return red(s)
    elif s == 'O':
        return green(s)
    else:
        return yellow(s)