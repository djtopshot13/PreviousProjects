# Import statements for util.py to work

from interface import red, yellow, green, cyan

# Logo uses the color functions and print functions to create an inviting welcome to the user when starting the process.

def logo():
    """Display the game's colorful logo"""
    print()
    print(red('888888888               '), yellow('888888888                '), green('888888888                 '))
    print(red('"8888888" ooooo  ooooo  '), yellow('"8888888" ooo     ooooo  '), green('"8888888"  ooo    ooooo   '))
    print(red('   888     888  88   8  '), yellow('   888    888    88   8  '), green('   888   88   88  8       '))
    print(red('   888     888  88      '), yellow('   888   8ooo8   88      '), green('   888   88   88  8ooooo  '))
    print(red('   888     888  88    88'), yellow('   888  888  888 88    88'), green('   888   88o  88 o88      '))
    print(red('   888    88888  888888"'), yellow('   888  888  888  888888"'), green('   888   "888888 888888888'))
    print("                                                            ", "by ", yellow("DuckieCorp"), "(tm)", sep='')
    print(cyan("\nWOULD YOU LIKE TO PLAY A GAME?\n"))

# The make_board function is key to the presentation of the game and making sure positions are correctly represented throughout.

def make_board():
    """
    A board is a 3-tuple of 3-tuples, where each tuple is one row
    """
    return tuple([1, 2, 3, 4, 5, 6, 7, 8, 9])

# This function is very helpful when the game function is called and runs many games at a very high speed.

def home():
    """return cursor to home position (upper left corner)"""
    print(end="\x1b[H")

# This function is used to reset the game board for a fresh start to help the user follow along by clearing out old games.

def clear():
    """clear the screen and return cursor to home position"""
    print(end="\x1b[H\x1b[J", flush=True)